PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS films (
  film_id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  genre TEXT NOT NULL,
  duration_min INTEGER NOT NULL CHECK(duration_min > 0),
  age_rating TEXT NOT NULL,
  description TEXT
);
CREATE TABLE IF NOT EXISTS halls (
  hall_id INTEGER PRIMARY KEY AUTOINCREMENT,
  hall_name TEXT NOT NULL UNIQUE,
  rows_count INTEGER NOT NULL CHECK(rows_count > 0),
  seats_per_row INTEGER NOT NULL CHECK(seats_per_row > 0)
);
CREATE TABLE IF NOT EXISTS seats (
  seat_id INTEGER PRIMARY KEY AUTOINCREMENT,
  hall_id INTEGER NOT NULL REFERENCES halls(hall_id),
  row_no INTEGER NOT NULL CHECK(row_no > 0),
  seat_no INTEGER NOT NULL CHECK(seat_no > 0),
  seat_type TEXT NOT NULL DEFAULT 'standard' CHECK(seat_type IN ('standard','vip')),
  UNIQUE(hall_id,row_no,seat_no)
);
CREATE TABLE IF NOT EXISTS sessions (
  session_id INTEGER PRIMARY KEY AUTOINCREMENT,
  film_id INTEGER NOT NULL REFERENCES films(film_id),
  hall_id INTEGER NOT NULL REFERENCES halls(hall_id),
  starts_at TEXT NOT NULL,
  base_price NUMERIC NOT NULL CHECK(base_price >= 0),
  UNIQUE(hall_id, starts_at)
);
CREATE TABLE IF NOT EXISTS customers (
  customer_id INTEGER PRIMARY KEY AUTOINCREMENT,
  full_name TEXT NOT NULL,
  phone TEXT
);
CREATE TABLE IF NOT EXISTS sales (
  sale_id INTEGER PRIMARY KEY AUTOINCREMENT,
  sold_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  total_amount NUMERIC NOT NULL CHECK(total_amount >= 0),
  customer_id INTEGER REFERENCES customers(customer_id)
);
CREATE TABLE IF NOT EXISTS tickets (
  ticket_id INTEGER PRIMARY KEY AUTOINCREMENT,
  ticket_number TEXT NOT NULL UNIQUE,
  sale_id INTEGER NOT NULL REFERENCES sales(sale_id),
  session_id INTEGER NOT NULL REFERENCES sessions(session_id),
  seat_id INTEGER NOT NULL REFERENCES seats(seat_id),
  price_at_sale NUMERIC NOT NULL CHECK(price_at_sale >= 0),
  status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','returned')),
  returned_at TEXT
);
-- Защита от повторной продажи: одновременно может существовать только один активный билет
CREATE UNIQUE INDEX IF NOT EXISTS ux_active_ticket
ON tickets(session_id, seat_id) WHERE status='active';

CREATE TABLE IF NOT EXISTS returns (
  return_id INTEGER PRIMARY KEY AUTOINCREMENT,
  ticket_id INTEGER NOT NULL UNIQUE REFERENCES tickets(ticket_id),
  returned_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  reason TEXT
);
