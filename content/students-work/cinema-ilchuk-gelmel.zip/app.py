from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3, uuid
from pathlib import Path
app = Flask(__name__)
app.secret_key = "cinema-demo-secret"
DB = Path(__file__).with_name("cinema.db")
SCHEMA = Path(__file__).with_name("schema.sql").read_text(encoding="utf-8")

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    return con

def init_db():
    con=db()
    con.executescript(SCHEMA)
    if con.execute("SELECT COUNT(*) FROM films").fetchone()[0] == 0:
        con.executemany("INSERT INTO films(title,genre,duration_min,age_rating,description) VALUES(?,?,?,?,?)", [
            ("Интерстеллар","Фантастика",169,"12+","Научно-фантастический фильм"),
            ("Начало","Фантастика, триллер",148,"12+","История о проникновении в сны"),
            ("1+1","Драма, комедия",112,"16+","История необычной дружбы")])
        con.executemany("INSERT INTO halls(hall_name,rows_count,seats_per_row) VALUES(?,?,?)", [
            ("Зал 1",5,8),("Зал 2",4,6)])
        for hall_id, rows, cols in [(1,5,8),(2,4,6)]:
            for r in range(1,rows+1):
                for s in range(1,cols+1):
                    con.execute("INSERT INTO seats(hall_id,row_no,seat_no,seat_type) VALUES(?,?,?,?)",
                                (hall_id,r,s,"vip" if r==1 and s in (4,5) else "standard"))
        con.executemany("INSERT INTO sessions(film_id,hall_id,starts_at,base_price) VALUES(?,?,?,?)", [
            (1,1,"2026-11-20T18:30",350),(2,2,"2026-11-20T19:00",300),
            (3,1,"2026-11-20T21:30",280)])
    con.commit(); con.close()

@app.route("/")
def index():
    con=db()
    date=request.args.get("date","2026-11-20")
    sessions=con.execute("""SELECT s.*, f.title, f.duration_min, h.hall_name,
      (SELECT COUNT(*) FROM tickets t WHERE t.session_id=s.session_id AND t.status='active') sold
      FROM sessions s JOIN films f USING(film_id) JOIN halls h USING(hall_id)
      WHERE substr(s.starts_at,1,10)=? ORDER BY s.starts_at""",(date,)).fetchall()
    films=con.execute("SELECT * FROM films ORDER BY title").fetchall()
    halls=con.execute("SELECT * FROM halls ORDER BY hall_id").fetchall()
    con.close()
    return render_template("index.html", sessions=sessions, films=films, halls=halls, date=date)

@app.route("/session/<int:sid>")
def session(sid):
    con=db()
    row=con.execute("""SELECT s.*,f.title,h.hall_name FROM sessions s
      JOIN films f USING(film_id) JOIN halls h USING(hall_id) WHERE session_id=?""",(sid,)).fetchone()
    if not row: con.close(); return "Сеанс не найден",404
    seats=con.execute("""SELECT st.*, t.ticket_id FROM seats st
      LEFT JOIN tickets t ON t.seat_id=st.seat_id AND t.session_id=? AND t.status='active'
      WHERE st.hall_id=? ORDER BY st.row_no,st.seat_no""",(sid,row["hall_id"])).fetchall()
    con.close()
    return render_template("session.html", session=row, seats=seats)

@app.post("/sell/<int:sid>")
def sell(sid):
    chosen=request.form.getlist("seat_ids")
    if not chosen: flash("Выберите хотя бы одно место."); return redirect(url_for("session",sid=sid))
    con=db()
    try:
        con.execute("BEGIN IMMEDIATE")
        s=con.execute("SELECT hall_id,base_price FROM sessions WHERE session_id=?",(sid,)).fetchone()
        if not s: raise ValueError("Сеанс не найден.")
        ids=[int(x) for x in chosen]
        q=",".join("?" for _ in ids)
        valid=con.execute(f"SELECT seat_id FROM seats WHERE hall_id=? AND seat_id IN ({q})",(s["hall_id"],*ids)).fetchall()
        if len(valid)!=len(set(ids)): raise ValueError("Некоторые места не относятся к залу сеанса.")
        occupied=con.execute(f"""SELECT seat_id FROM tickets WHERE session_id=? AND status='active'
          AND seat_id IN ({q})""",(sid,*ids)).fetchall()
        if occupied: raise ValueError("Одно или несколько выбранных мест уже заняты. Продажа отменена.")
        amount=float(s["base_price"])*len(ids)
        cur=con.execute("INSERT INTO sales(total_amount) VALUES(?)",(amount,))
        sale_id=cur.lastrowid
        for seat_id in ids:
            number="K"+uuid.uuid4().hex[:10].upper()
            con.execute("INSERT INTO tickets(ticket_number,sale_id,session_id,seat_id,price_at_sale,status) VALUES(?,?,?,?,?,'active')",
                        (number,sale_id,sid,seat_id,s["base_price"]))
        con.commit()
        flash(f"Продажа выполнена. Билетов: {len(ids)}. Сумма: {amount:.2f} руб.")
    except Exception as e:
        con.rollback(); flash(str(e))
    finally: con.close()
    return redirect(url_for("session",sid=sid))

@app.route("/returns", methods=["GET","POST"])
def returns():
    con=db()
    if request.method=="POST":
        number=request.form.get("ticket_number","").strip()
        try:
            con.execute("BEGIN IMMEDIATE")
            t=con.execute("SELECT * FROM tickets WHERE ticket_number=? AND status='active'",(number,)).fetchone()
            if not t: raise ValueError("Действующий билет с таким номером не найден.")
            con.execute("UPDATE tickets SET status='returned', returned_at=CURRENT_TIMESTAMP WHERE ticket_id=?",(t["ticket_id"],))
            con.execute("INSERT INTO returns(ticket_id,reason) VALUES(?,?)",(t["ticket_id"],"Возврат через интерфейс"))
            con.commit(); flash("Возврат оформлен. Место освобождено.")
        except Exception as e: con.rollback(); flash(str(e))
    tickets=con.execute("""SELECT t.ticket_number,f.title,s.starts_at,st.row_no,st.seat_no,t.price_at_sale
      FROM tickets t JOIN sessions s USING(session_id) JOIN films f USING(film_id)
      JOIN seats st USING(seat_id) WHERE t.status='active' ORDER BY t.ticket_id DESC""").fetchall()
    con.close()
    return render_template("returns.html",tickets=tickets)

@app.post("/add-session")
def add_session():
    con=db()
    try:
        con.execute("INSERT INTO sessions(film_id,hall_id,starts_at,base_price) VALUES(?,?,?,?)",
                    (request.form["film_id"],request.form["hall_id"],request.form["starts_at"],request.form["base_price"]))
        con.commit(); flash("Сеанс добавлен.")
    except Exception as e: con.rollback(); flash(f"Не удалось добавить сеанс: {e}")
    finally: con.close()
    return redirect(url_for("index"))

if __name__=="__main__":
    init_db()
    app.run(debug=True)
