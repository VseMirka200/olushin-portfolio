#!/usr/bin/env python3
"""ЗАДАНИЕ 4. Веб-приложение «Библиотека».
Запуск:  python app.py   →  http://127.0.0.1:8000
Нужен только Python 3.8+ (стандартная библиотека). БД library.db создаётся
автоматически из schema.sql и data.sql. Чтобы начать заново — удалите library.db."""
import os, sqlite3, html
from datetime import date, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, quote

HERE = os.path.dirname(os.path.abspath(__file__))
DB = os.environ.get("LIBRARY_DB", os.path.join(HERE, "library.db"))
STATES = {"good": "хорошее", "worn": "потрёпанный", "damaged": "повреждён"}


class Err(Exception):
    """Ошибка проверки ввода / нарушение правил учёта — текст показывается пользователю."""


def db():
    c = sqlite3.connect(DB, isolation_level=None)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys = ON")
    c.create_function("ulower", 1, lambda s: s.lower() if s else s)  # регистронезависимый поиск по кириллице
    return c


def init_db():
    if os.path.exists(DB):
        return
    c = db()
    for name in ("schema.sql", "data.sql"):
        with open(os.path.join(HERE, name), encoding="utf-8") as f:
            c.executescript(f.read())
    c.close()


class tx:
    """Транзакция: BEGIN IMMEDIATE ... COMMIT, при любой ошибке — ROLLBACK."""
    def __enter__(self):
        self.c = db()
        self.c.execute("BEGIN IMMEDIATE")
        return self.c

    def __exit__(self, t, v, tb):
        try:
            self.c.execute("ROLLBACK" if t else "COMMIT")
        finally:
            self.c.close()
        return False


today = lambda: date.today().isoformat()
E = lambda v: html.escape("" if v is None else str(v))

CSS = """*{box-sizing:border-box}body{margin:0;font:15px/1.5 system-ui,sans-serif;background:#f4f5f7;color:#1d2330}
header{background:#24324a;color:#fff;padding:10px 24px;display:flex;gap:28px;align-items:center;flex-wrap:wrap}
nav a{color:#cfd8e8;text-decoration:none;margin-right:16px;padding:4px 0}nav a.on,nav a:hover{color:#fff;border-bottom:2px solid #6aa3ff}
main{max-width:1050px;margin:0 auto;padding:12px 24px 40px}h1{font-size:22px}h2{font-size:17px;margin-top:28px}
table{border-collapse:collapse;width:100%;background:#fff}th,td{border:1px solid #dfe3ea;padding:6px 9px;text-align:left;vertical-align:top}
th{background:#eaeef5}.card{background:#fff;border:1px solid #dfe3ea;border-radius:8px;padding:14px 16px;margin:10px 0;display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:10px 16px;align-items:end}
label{display:flex;flex-direction:column;font-size:13px;color:#46506a;gap:3px}input,select{font:inherit;padding:6px 8px;border:1px solid #b9c1d1;border-radius:5px;background:#fff}
button{font:inherit;padding:7px 14px;border:0;border-radius:5px;background:#2f6fe4;color:#fff;cursor:pointer}button:hover{background:#2358b8}
.req{color:#d12;margin-left:2px}.hint{grid-column:1/-1;margin:0;font-size:12.5px;color:#667}
.msg{padding:10px 14px;border-radius:6px;margin:12px 0;font-weight:500}.ok{background:#e1f6e6;color:#17622a;border:1px solid #9fd8ac}.err{background:#fde8e8;color:#9b1c1c;border:1px solid #f1a9a9}
.bad{color:#b42318;font-weight:600}.good{color:#17622a}a{color:#1f56c4}td form{display:inline;margin:0}td input,td select{padding:3px 6px;width:100%}"""


def layout(title, body, msg="", kind="ok", active=""):
    nav = "".join(f'<a href="{h}"{" class=on" if h == active else ""}>{t}</a>' for h, t in
                  [("/catalog", "Каталог"), ("/readers", "Читатели"), ("/loans", "Выдача и возврат"), ("/overdue", "Просрочка")])
    m = f'<div class="msg {"err" if kind == "err" else "ok"}">{E(msg)}</div>' if msg else ""
    return (f"<!doctype html><html lang=ru><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'>"
            f"<title>{E(title)} — Библиотека</title><style>{CSS}</style><header><b>📚 Библиотека</b><nav>{nav}</nav></header>"
            f"<main>{m}<h1>{E(title)}</h1>{body}</main></html>")


def field(label, name, value="", req=False, type="text", extra=""):
    star = '<span class=req>*</span>' if req else ""
    return (f'<label>{E(label)}{star}<input type="{type}" name="{name}" value="{E(value)}" '
            f'{"required" if req else ""} {extra}></label>')


def select(label, name, options, selected=None):
    opts = "".join(f'<option value="{E(v)}"{" selected" if str(v) == str(selected) else ""}>{E(t)}</option>' for v, t in options)
    return f'<label>{E(label)}<span class=req style="display:inline">*</span><select name="{name}" required>{opts}</select></label>'


def table(head, rows):
    if not rows:
        return "<p>Нет данных.</p>"
    return ("<table><tr>" + "".join(f"<th>{h}</th>" for h in head) + "</tr>" +
            "".join("<tr>" + "".join(f"<td>{c}</td>" for c in r) + "</tr>" for r in rows) + "</table>")


HINT = '<p class=hint><span class=req>*</span> — обязательное поле</p>'
hidden = lambda n, v: f'<input type=hidden name="{n}" value="{E(v)}">'
status = lambda r: "возвращена" if r["return_date"] else ('<span class=bad>просрочена</span>' if r["due_date"] < today() else "на руках")

# ----------------------------------------------------------------- страницы (GET)
SQL_BOOKS = """
SELECT b.book_id, b.title, b.isbn, b.publish_year, g.name AS genre, p.name AS publisher,
  (SELECT group_concat(a.full_name, ', ') FROM book_authors ba JOIN authors a USING(author_id) WHERE ba.book_id = b.book_id) AS authors,
  (SELECT COUNT(*) FROM copies c WHERE c.book_id = b.book_id) AS total,
  (SELECT COUNT(*) FROM copies c WHERE c.book_id = b.book_id AND NOT EXISTS
      (SELECT 1 FROM loans l WHERE l.copy_id = c.copy_id AND l.return_date IS NULL)) AS free
FROM books b LEFT JOIN genres g USING(genre_id) LEFT JOIN publishers p USING(publisher_id)
WHERE :s = '' OR ulower(b.title) LIKE :p OR EXISTS (SELECT 1 FROM book_authors ba JOIN authors a USING(author_id)
      WHERE ba.book_id = b.book_id AND ulower(a.full_name) LIKE :p)
ORDER BY b.title"""


def book_form(c, b=None, authors="", back="/catalog"):
    b = b or {}
    pubs = "".join(f"<option value='{E(r[0])}'>" for r in c.execute("SELECT name FROM publishers ORDER BY name"))
    gens = "".join(f"<option value='{E(r[0])}'>" for r in c.execute("SELECT name FROM genres ORDER BY name"))
    return (f'<form method=post action=/book/save class=card>{hidden("back", back)}{hidden("id", b.get("book_id", ""))}'
            f'{field("Название", "title", b.get("title"), True)}{field("Авторы (через запятую)", "authors", authors, True)}'
            f'{field("ISBN", "isbn", b.get("isbn"))}{field("Год издания", "year", b.get("publish_year"), type="number", extra="min=1450 max=2100")}'
            f'{field("Издательство", "publisher", b.get("publisher"), extra="list=pubs")}{field("Жанр", "genre", b.get("genre"), extra="list=gens")}'
            f'<datalist id=pubs>{pubs}</datalist><datalist id=gens>{gens}</datalist>{HINT}<button>Сохранить книгу</button></form>')


def p_catalog(q):
    c = db()
    s = q.get("q", "").strip().lower()
    rows = [[f'<a href="/book/{r["book_id"]}">{E(r["title"])}</a>', E(r["authors"]), E(r["genre"]), E(r["publisher"]),
             E(r["publish_year"]), f'{r["free"]} из {r["total"]}'] for r in c.execute(SQL_BOOKS, {"s": s, "p": f"%{s}%"})]
    body = (f'<form method=get class=card>{field("Поиск по названию или автору", "q", q.get("q", ""))}<button>Найти</button></form>'
            + table(["Название", "Авторы", "Жанр", "Издательство", "Год", "Свободно экз."], rows)
            + "<h2>Добавить книгу</h2>" + book_form(c))
    return layout("Каталог книг", body, active="/catalog")


def p_book(bid, q):
    c = db()
    b = c.execute("""SELECT b.*, p.name AS publisher, g.name AS genre FROM books b LEFT JOIN publishers p USING(publisher_id)
                     LEFT JOIN genres g USING(genre_id) WHERE b.book_id = ?""", (bid,)).fetchone()
    if not b:
        return None
    authors = ", ".join(r[0] for r in c.execute(
        "SELECT a.full_name FROM book_authors ba JOIN authors a USING(author_id) WHERE ba.book_id = ? ORDER BY a.full_name", (bid,)))
    rows = []
    for r in c.execute("""SELECT c.*, (SELECT rd.full_name FROM loans l JOIN readers rd USING(reader_id)
                          WHERE l.copy_id = c.copy_id AND l.return_date IS NULL) AS holder
                          FROM copies c WHERE book_id = ? ORDER BY inventory_number""", (bid,)):
        opts = "".join(f'<option value="{k}"{" selected" if k == r["state"] else ""}>{v}</option>' for k, v in STATES.items())
        fid = f'cf{r["copy_id"]}'
        rows.append([f'<form id={fid} method=post action=/copy/save>{hidden("copy_id", r["copy_id"])}{hidden("back", f"/book/{bid}")}</form>'
                     f'<input form={fid} name=inventory_number value="{E(r["inventory_number"])}" required>',
                     f'<select form={fid} name=state>{opts}</select>',
                     f'выдан: {E(r["holder"])}' if r["holder"] else '<span class=good>свободен</span>',
                     f'<button form={fid}>Сохранить</button>'])
    add = (f'<form method=post action=/copy/save class=card>{hidden("book_id", bid)}{hidden("back", f"/book/{bid}")}'
           f'{field("Инвентарный номер", "inventory_number", "", True)}'
           f'{select("Состояние", "state", list(STATES.items()))}{HINT}<button>Добавить экземпляр</button></form>')
    body = ("<p><a href=/catalog>← К каталогу</a></p>" + book_form(c, dict(b), authors, f"/book/{bid}")
            + "<h2>Экземпляры</h2>" + table(["Инв. номер", "Состояние", "Статус", ""], rows) + "<h2>Новый экземпляр</h2>" + add)
    return layout(f"Книга: {b['title']}", body, active="/catalog")


def p_readers(q):
    c = db()
    s = q.get("q", "").strip().lower()
    rows = [[f'<a href="/reader/{r["reader_id"]}">{E(r["full_name"])}</a>', E(r["card_number"]), E(r["phone"]), E(r["email"]),
             E(r["registered_at"]), r["open_loans"]] for r in c.execute("""
        SELECT r.*, (SELECT COUNT(*) FROM loans l WHERE l.reader_id = r.reader_id AND l.return_date IS NULL) AS open_loans
        FROM readers r WHERE :s = '' OR ulower(r.full_name) LIKE :p OR ulower(r.card_number) LIKE :p OR r.phone LIKE :p
        ORDER BY r.full_name""", {"s": s, "p": f"%{s}%"})]
    reg = (f'<form method=post action=/reader/save class=card>{hidden("back", "/readers")}'
           f'{field("ФИО", "full_name", "", True)}{field("Номер читательского билета", "card_number", "", True)}'
           f'{field("Телефон", "phone")}{field("E-mail", "email", type="email")}{HINT}<button>Зарегистрировать</button></form>')
    body = (f'<form method=get class=card>{field("Поиск по ФИО, номеру билета или телефону", "q", q.get("q", ""))}<button>Найти</button></form>'
            + table(["ФИО", "Билет", "Телефон", "E-mail", "Регистрация", "Книг на руках"], rows) + "<h2>Регистрация читателя</h2>" + reg)
    return layout("Читатели", body, active="/readers")


def p_reader(rid):
    c = db()
    r = c.execute("SELECT * FROM readers WHERE reader_id = ?", (rid,)).fetchone()
    if not r:
        return None
    rows = [[E(h["title"]), E(h["inventory_number"]), E(h["issue_date"]), E(h["due_date"]), E(h["return_date"]), status(h)]
            for h in c.execute("""SELECT l.*, b.title, c.inventory_number FROM loans l JOIN copies c USING(copy_id)
                                  JOIN books b USING(book_id) WHERE l.reader_id = ? ORDER BY l.issue_date DESC, l.loan_id DESC""", (rid,))]
    info = f"<p>Билет <b>{E(r['card_number'])}</b>, телефон: {E(r['phone']) or '—'}, e-mail: {E(r['email']) or '—'}, регистрация: {E(r['registered_at'])}</p>"
    return layout(f"История выдач: {r['full_name']}", "<p><a href=/readers>← К читателям</a></p>" + info +
                  table(["Книга", "Инв. №", "Выдана", "Вернуть до", "Возвращена", "Статус"], rows), active="/readers")


def p_loans(q):
    c = db()
    readers = [(r[0], f"{r[1]} ({r[2]})") for r in c.execute("SELECT reader_id, full_name, card_number FROM readers ORDER BY full_name")]
    libs = [(r[0], r[1]) for r in c.execute("SELECT librarian_id, full_name FROM librarians ORDER BY full_name")]
    copies = [(r["copy_id"], f'{r["title"]} — {r["inventory_number"]}' + (" (выдан)" if r["busy"] else "")) for r in c.execute("""
        SELECT c.copy_id, c.inventory_number, b.title, EXISTS(SELECT 1 FROM loans l WHERE l.copy_id = c.copy_id AND l.return_date IS NULL) AS busy
        FROM copies c JOIN books b USING(book_id) ORDER BY b.title, c.inventory_number""")]
    due = (date.today() + timedelta(days=14)).isoformat()
    issue = (f'<form method=post action=/loan/issue class=card>{hidden("back", "/loans")}{select("Читатель", "reader_id", readers)}'
             f'{select("Экземпляр", "copy_id", copies)}{select("Библиотекарь", "librarian_id", libs)}'
             f'{field("Срок возврата", "due_date", due, True, "date", f"min={today()}")}{HINT}<button>Выдать книгу</button></form>')
    sel = """SELECT l.*, b.title, c.inventory_number, r.full_name FROM loans l JOIN copies c USING(copy_id) JOIN books b USING(book_id)
             JOIN readers r USING(reader_id) WHERE l.return_date {} ORDER BY l.issue_date DESC, l.loan_id DESC {}"""
    op = [[E(h["title"]), E(h["inventory_number"]), E(h["full_name"]), E(h["issue_date"]), E(h["due_date"]), status(h),
           f'<form method=post action=/loan/return>{hidden("back", "/loans")}{hidden("loan_id", h["loan_id"])}<button>Принять возврат</button></form>']
          for h in c.execute(sel.format("IS NULL", ""))]
    cl = [[E(h["title"]), E(h["inventory_number"]), E(h["full_name"]), E(h["issue_date"]), E(h["return_date"])]
          for h in c.execute(sel.format("IS NOT NULL", "LIMIT 15"))]
    body = (issue + "<h2>Открытые выдачи</h2>" + table(["Книга", "Инв. №", "Читатель", "Выдана", "Вернуть до", "Статус", ""], op)
            + "<h2>Последние возвраты</h2>" + table(["Книга", "Инв. №", "Читатель", "Выдана", "Возвращена"], cl))
    return layout("Выдача и возврат", body, active="/loans")


def p_overdue(q):
    rows = [[E(h["full_name"]), E(h["card_number"]), E(h["phone"]), E(h["title"]), E(h["inventory_number"]), E(h["due_date"]),
             f'<span class=bad>{h["days"]}</span>'] for h in db().execute("""
        SELECT l.*, r.full_name, r.card_number, r.phone, b.title, c.inventory_number, CAST(julianday(?) - julianday(l.due_date) AS INTEGER) AS days
        FROM loans l JOIN readers r USING(reader_id) JOIN copies c USING(copy_id) JOIN books b USING(book_id)
        WHERE l.return_date IS NULL AND l.due_date < ? ORDER BY days DESC""", (today(), today()))]
    return layout("Просроченные выдачи", table(["Читатель", "Билет", "Телефон", "Книга", "Инв. №", "Срок был", "Дней просрочки"], rows), active="/overdue")


# ----------------------------------------------------------------- действия (POST)
def get_or_create(c, tbl, col, idcol, val):
    if not val:
        return None
    r = c.execute(f"SELECT {idcol} FROM {tbl} WHERE {col} = ?", (val,)).fetchone()
    return r[0] if r else c.execute(f"INSERT INTO {tbl}({col}) VALUES (?)", (val,)).lastrowid


def save_book(f):
    title = f.get("title", "")
    authors = [a.strip() for a in f.get("authors", "").split(",") if a.strip()]
    year = f.get("year", "")
    if not title:
        raise Err("Укажите название книги")
    if not authors:
        raise Err("Укажите хотя бы одного автора")
    if year and not (year.isdigit() and 1450 <= int(year) <= 2100):
        raise Err("Год издания должен быть числом от 1450 до 2100")
    try:
        with tx() as c:
            pid = get_or_create(c, "publishers", "name", "publisher_id", f.get("publisher", ""))
            gid = get_or_create(c, "genres", "name", "genre_id", f.get("genre", ""))
            vals = (title, f.get("isbn") or None, int(year) if year else None, pid, gid)
            if f.get("id"):
                bid = int(f["id"])
                c.execute("UPDATE books SET title=?, isbn=?, publish_year=?, publisher_id=?, genre_id=? WHERE book_id=?", vals + (bid,))
                c.execute("DELETE FROM book_authors WHERE book_id = ?", (bid,))
            else:
                bid = c.execute("INSERT INTO books(title, isbn, publish_year, publisher_id, genre_id) VALUES (?,?,?,?,?)", vals).lastrowid
            for a in authors:
                c.execute("INSERT OR IGNORE INTO book_authors(book_id, author_id) VALUES (?,?)", (bid, get_or_create(c, "authors", "full_name", "author_id", a)))
    except sqlite3.IntegrityError:
        raise Err("Книга с таким ISBN уже есть в каталоге")
    return "Книга сохранена"


def save_copy(f):
    inv, state = f.get("inventory_number", ""), f.get("state", "good")
    if not inv:
        raise Err("Укажите инвентарный номер")
    if state not in STATES:
        raise Err("Недопустимое состояние экземпляра")
    try:
        with tx() as c:
            if f.get("copy_id"):
                c.execute("UPDATE copies SET inventory_number=?, state=? WHERE copy_id=?", (inv, state, int(f["copy_id"])))
            else:
                c.execute("INSERT INTO copies(book_id, inventory_number, state) VALUES (?,?,?)", (int(f["book_id"]), inv, state))
    except sqlite3.IntegrityError:
        raise Err(f"Инвентарный номер «{inv}» уже существует")
    return "Экземпляр сохранён"


def save_reader(f):
    name, card, email = f.get("full_name", ""), f.get("card_number", ""), f.get("email", "")
    if not name or not card:
        raise Err("Заполните ФИО и номер читательского билета")
    if email and ("@" not in email or "." not in email.split("@")[-1]):
        raise Err("Некорректный e-mail")
    try:
        with tx() as c:
            c.execute("INSERT INTO readers(full_name, card_number, phone, email) VALUES (?,?,?,?)",
                      (name, card, f.get("phone") or None, email or None))
    except sqlite3.IntegrityError:
        raise Err(f"Читатель с билетом «{card}» уже зарегистрирован")
    return "Читатель зарегистрирован"


def issue_loan(f):
    try:
        rid, cid, lid = int(f["reader_id"]), int(f["copy_id"]), int(f["librarian_id"])
    except (KeyError, ValueError):
        raise Err("Выберите читателя, экземпляр и библиотекаря")
    try:
        due = date.fromisoformat(f.get("due_date", ""))
    except ValueError:
        raise Err("Укажите срок возврата (ГГГГ-ММ-ДД)")
    if due < date.today():
        raise Err("Срок возврата не может быть раньше даты выдачи")
    try:
        with tx() as c:  # проверка доступности + запись выдачи — одна транзакция
            if c.execute("SELECT 1 FROM loans WHERE copy_id = ? AND return_date IS NULL", (cid,)).fetchone():
                raise Err("Экземпляр уже выдан — повторная выдача отклонена")
            c.execute("INSERT INTO loans(copy_id, reader_id, librarian_id, issue_date, due_date) VALUES (?,?,?,?,?)",
                      (cid, rid, lid, today(), due.isoformat()))
    except sqlite3.IntegrityError:
        raise Err("Экземпляр уже выдан или данные выдачи некорректны")
    return "Книга выдана"


def return_loan(f):
    with tx() as c:
        if not c.execute("SELECT 1 FROM loans WHERE loan_id = ? AND return_date IS NULL", (f.get("loan_id"),)).fetchone():
            raise Err("Выдача не найдена или уже закрыта")
        c.execute("UPDATE loans SET return_date = ? WHERE loan_id = ?", (today(), f["loan_id"]))
    return "Возврат оформлен, экземпляр снова доступен"


GET = {"/catalog": p_catalog, "/readers": p_readers, "/loans": p_loans, "/overdue": p_overdue}
POST = {"/book/save": save_book, "/copy/save": save_copy, "/reader/save": save_reader, "/loan/issue": issue_loan, "/loan/return": return_loan}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def send(self, code, body="", loc=None):
        self.send_response(code)
        if loc:
            self.send_header("Location", loc)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        data = body.encode()
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        u = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        try:
            if u.path == "/":
                return self.send(303, loc="/catalog")
            if u.path in GET:
                page = GET[u.path](q)
            elif u.path.startswith("/book/"):
                page = p_book(int(u.path[6:]), q)
            elif u.path.startswith("/reader/"):
                page = p_reader(int(u.path[8:]))
            else:
                page = None
        except ValueError:
            page = None
        if page is None:
            return self.send(404, layout("Страница не найдена", "<p><a href=/catalog>На главную</a></p>"))
        if q.get("m"):  # сообщение об успехе / ошибке после действия
            page = page.replace("<main>", f'<main><div class="msg {"err" if q.get("t") == "err" else "ok"}">{E(q["m"])}</div>', 1)
        self.send(200, page)

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        f = {k: v[0].strip() for k, v in parse_qs(self.rfile.read(n).decode(), keep_blank_values=True).items()}
        back = f.get("back", "/catalog")
        if not back.startswith("/") or back.startswith("//"):
            back = "/catalog"
        if self.path not in POST:
            return self.send(404, "Not found")
        try:
            msg, kind = POST[self.path](f), "ok"
        except Err as ex:
            msg, kind = str(ex), "err"
        self.send(303, loc=f"{back.split('?')[0]}?m={quote(msg)}&t={kind}")


if __name__ == "__main__":
    init_db()
    port = int(os.environ.get("PORT", 8000))
    print(f"Библиотека: http://127.0.0.1:{port}  (Ctrl+C — остановка)")
    ThreadingHTTPServer(("127.0.0.1", port), Handler).serve_forever()
