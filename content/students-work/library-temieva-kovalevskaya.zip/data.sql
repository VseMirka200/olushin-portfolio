-- Тестовые данные. Даты считаются от текущего дня, чтобы просрочка была всегда.
PRAGMA foreign_keys = ON;

INSERT INTO librarians(full_name, login) VALUES
 ('Смирнова Анна Петровна', 'smirnova'),
 ('Орлов Игорь Сергеевич',  'orlov');

INSERT INTO publishers(name, city) VALUES ('Эксмо','Москва'), ('АСТ','Москва'), ('Азбука','Санкт-Петербург');
INSERT INTO genres(name) VALUES ('Роман'), ('Фантастика'), ('Классика');

INSERT INTO authors(full_name, birth_year) VALUES
 ('Булгаков Михаил Афанасьевич', 1891),
 ('Толстой Лев Николаевич', 1828),
 ('Стругацкий Аркадий Натанович', 1925),
 ('Стругацкий Борис Натанович', 1933);

INSERT INTO books(title, isbn, publish_year, publisher_id, genre_id) VALUES
 ('Мастер и Маргарита',   '978-5-04-000001-1', 2020, 1, 1),
 ('Война и мир',          '978-5-17-000002-2', 2019, 2, 3),
 ('Пикник на обочине',    '978-5-17-000003-3', 2018, 3, 2);

INSERT INTO book_authors(book_id, author_id) VALUES (1,1), (2,2), (3,3), (3,4);

-- У книги «Мастер и Маргарита» три экземпляра
INSERT INTO copies(book_id, inventory_number, state) VALUES
 (1, 'INV-0001', 'good'), (1, 'INV-0002', 'good'), (1, 'INV-0003', 'worn'),
 (2, 'INV-0004', 'good'),
 (3, 'INV-0005', 'good'), (3, 'INV-0006', 'damaged');

INSERT INTO readers(full_name, card_number, phone, email) VALUES
 ('Иванов Пётр Алексеевич',   'R-0001', '+7 900 111-22-33', 'ivanov@example.com'),
 ('Кузнецова Мария Олеговна', 'R-0002', '+7 900 444-55-66', NULL),
 ('Соколов Дмитрий Иванович', 'R-0003', NULL, 'sokolov@example.com');

-- 1) Закрытая (историческая) выдача
INSERT INTO loans(copy_id, reader_id, librarian_id, issue_date, due_date, return_date) VALUES
 (2, 1, 1, date('now','localtime','-60 day'), date('now','localtime','-46 day'), date('now','localtime','-50 day'));
-- 2) Действующая выдача (срок ещё не истёк)
INSERT INTO loans(copy_id, reader_id, librarian_id, issue_date, due_date) VALUES
 (1, 1, 1, date('now','localtime','-5 day'),  date('now','localtime','+9 day'));
-- 3) Открытая выдача с истёкшим сроком возврата (просрочка)
INSERT INTO loans(copy_id, reader_id, librarian_id, issue_date, due_date) VALUES
 (4, 2, 2, date('now','localtime','-30 day'), date('now','localtime','-16 day'));
