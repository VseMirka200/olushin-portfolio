-- ЗАДАНИЕ 3. Схема БД «Библиотека» (SQLite 3). Создание: sqlite3 library.db < schema.sql
PRAGMA foreign_keys = ON;

-- ===== Дополнительные сущности =====
CREATE TABLE publishers (
    publisher_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name         TEXT NOT NULL UNIQUE CHECK (length(trim(name)) > 0),
    city         TEXT
);

CREATE TABLE genres (
    genre_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name     TEXT NOT NULL UNIQUE CHECK (length(trim(name)) > 0)
);

CREATE TABLE librarians (
    librarian_id INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name    TEXT NOT NULL CHECK (length(trim(full_name)) > 0),
    login        TEXT NOT NULL UNIQUE CHECK (length(trim(login)) > 0)
);

-- ===== Основные сущности =====
CREATE TABLE authors (
    author_id  INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name  TEXT NOT NULL UNIQUE CHECK (length(trim(full_name)) > 0),
    birth_year INTEGER CHECK (birth_year BETWEEN 1 AND 2100)
);

CREATE TABLE books (
    book_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    title        TEXT NOT NULL CHECK (length(trim(title)) > 0),
    isbn         TEXT UNIQUE,
    publish_year INTEGER CHECK (publish_year BETWEEN 1450 AND 2100),
    publisher_id INTEGER REFERENCES publishers(publisher_id) ON UPDATE CASCADE ON DELETE SET NULL,
    genre_id     INTEGER REFERENCES genres(genre_id)         ON UPDATE CASCADE ON DELETE SET NULL
);

-- Промежуточная таблица связи «многие ко многим» книга — автор
CREATE TABLE book_authors (
    book_id   INTEGER NOT NULL REFERENCES books(book_id)     ON DELETE CASCADE,
    author_id INTEGER NOT NULL REFERENCES authors(author_id) ON DELETE RESTRICT,
    PRIMARY KEY (book_id, author_id)
);

CREATE TABLE copies (
    copy_id          INTEGER PRIMARY KEY AUTOINCREMENT,
    book_id          INTEGER NOT NULL REFERENCES books(book_id) ON DELETE RESTRICT,
    inventory_number TEXT NOT NULL UNIQUE CHECK (length(trim(inventory_number)) > 0),
    state            TEXT NOT NULL DEFAULT 'good' CHECK (state IN ('good', 'worn', 'damaged'))
);

CREATE TABLE readers (
    reader_id     INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name     TEXT NOT NULL CHECK (length(trim(full_name)) > 0),
    card_number   TEXT NOT NULL UNIQUE CHECK (length(trim(card_number)) > 0),
    phone         TEXT,
    email         TEXT CHECK (email IS NULL OR email LIKE '%_@_%._%'),
    registered_at TEXT NOT NULL DEFAULT (date('now', 'localtime'))
                  CHECK (date(registered_at) = registered_at)
);

CREATE TABLE loans (
    loan_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    copy_id      INTEGER NOT NULL REFERENCES copies(copy_id)       ON DELETE RESTRICT,
    reader_id    INTEGER NOT NULL REFERENCES readers(reader_id)    ON DELETE RESTRICT,
    librarian_id INTEGER NOT NULL REFERENCES librarians(librarian_id) ON DELETE RESTRICT,
    issue_date   TEXT NOT NULL CHECK (date(issue_date) = issue_date),
    due_date     TEXT NOT NULL CHECK (date(due_date) = due_date),
    return_date  TEXT CHECK (return_date IS NULL OR date(return_date) = return_date),
    CHECK (due_date >= issue_date),                                  -- срок не раньше выдачи
    CHECK (return_date IS NULL OR return_date >= issue_date)         -- возврат не раньше выдачи
);

-- Правило учёта: у экземпляра допускается только ОДНА открытая выдача
CREATE UNIQUE INDEX ux_loans_one_open_per_copy ON loans(copy_id) WHERE return_date IS NULL;

CREATE INDEX ix_books_title    ON books(title);
CREATE INDEX ix_copies_book    ON copies(book_id);
CREATE INDEX ix_loans_reader   ON loans(reader_id);
CREATE INDEX ix_loans_due_open ON loans(due_date) WHERE return_date IS NULL;
