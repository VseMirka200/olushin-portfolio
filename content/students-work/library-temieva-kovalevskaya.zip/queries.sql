-- ЗАДАНИЕ 3. SQL-запросы

-- 1. Свободные экземпляры выбранной книги (book_id = 1)
SELECT c.copy_id, c.inventory_number, c.state
FROM copies c
WHERE c.book_id = 1
  AND NOT EXISTS (SELECT 1 FROM loans l WHERE l.copy_id = c.copy_id AND l.return_date IS NULL)
ORDER BY c.inventory_number;

-- 2. Просроченные выдачи (открытые, срок возврата истёк)
SELECT l.loan_id, r.full_name AS reader, r.card_number, b.title, c.inventory_number,
       l.issue_date, l.due_date,
       CAST(julianday(date('now','localtime')) - julianday(l.due_date) AS INTEGER) AS days_overdue
FROM loans l
JOIN readers r ON r.reader_id = l.reader_id
JOIN copies  c ON c.copy_id   = l.copy_id
JOIN books   b ON b.book_id   = c.book_id
WHERE l.return_date IS NULL AND l.due_date < date('now','localtime')
ORDER BY days_overdue DESC;

-- 3. История выдач выбранного читателя (reader_id = 1)
SELECT l.loan_id, b.title, c.inventory_number, l.issue_date, l.due_date, l.return_date,
       CASE WHEN l.return_date IS NOT NULL THEN 'возвращена'
            WHEN l.due_date < date('now','localtime') THEN 'просрочена'
            ELSE 'на руках' END AS status
FROM loans l
JOIN copies c ON c.copy_id = l.copy_id
JOIN books  b ON b.book_id = c.book_id
WHERE l.reader_id = 1
ORDER BY l.issue_date DESC;

-- ===== Транзакции =====
-- Выдача: проверка доступности и запись о выдаче — одна транзакция
-- (:copy, :reader, :librarian, :due — параметры)
BEGIN IMMEDIATE;
  -- если запрос вернул строку — экземпляр занят, делаем ROLLBACK
  SELECT 1 FROM loans WHERE copy_id = :copy AND return_date IS NULL;
  INSERT INTO loans(copy_id, reader_id, librarian_id, issue_date, due_date)
  VALUES (:copy, :reader, :librarian, date('now','localtime'), :due);
COMMIT;

-- Возврат: закрываем выдачу, экземпляр снова свободен
BEGIN IMMEDIATE;
  UPDATE loans SET return_date = date('now','localtime')
  WHERE loan_id = :loan AND return_date IS NULL;
COMMIT;
