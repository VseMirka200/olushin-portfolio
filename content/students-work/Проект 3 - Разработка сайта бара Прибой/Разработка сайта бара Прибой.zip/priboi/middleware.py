from django.http import Http404


class HideAdminFromNonStaffMiddleware:
    """
    Скрываем /admin/ от всех, кроме авторизованных staff-пользователей.

    Анонимные и обычные юзеры получают 404 — даже страница входа в админку
    не должна быть видна. Админ заходит на сайт через обычный /accounts/login/,
    а уже потом /admin/ становится доступен.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.path.startswith('/admin/') and not (
            request.user.is_authenticated and request.user.is_staff
        ):
            raise Http404('Page not found')
        return self.get_response(request)
