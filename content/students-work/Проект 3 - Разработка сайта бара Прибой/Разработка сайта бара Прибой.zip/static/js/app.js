document.addEventListener('alpine:init', () => {

    Alpine.store('cart', {
        items: [],
        pickupDate: '',
        pickupTime: '',

        add(service) {
            const existing = this.items.find(i => i.id === service.id);
            if (existing) {
                existing.quantity += 1;
            } else {
                this.items.push({
                    id: service.id,
                    name: service.name,
                    price: Number(service.price),
                    quantity: 1,
                });
            }
        },

        remove(index) {
            this.items.splice(index, 1);
        },

        adjust(index, delta) {
            const item = this.items[index];
            if (!item) return;
            item.quantity += delta;
            if (item.quantity <= 0) this.remove(index);
        },

        clear() {
            this.items = [];
            this.pickupDate = '';
            this.pickupTime = '';
        },

        get total() {
            return this.items.reduce((sum, i) => sum + i.price * i.quantity, 0);
        },

        get count() {
            return this.items.reduce((sum, i) => sum + i.quantity, 0);
        },

        serialize() {
            return JSON.stringify(this.items.map(({ id, quantity }) => ({ id, quantity })));
        },
    });

    Alpine.store('modal', {
        open: false,
        tab: 'products',
        prefill: {},
        productsLoaded: false,

        show(tab = 'products', prefill = {}) {
            this.prefill = prefill;
            this.open = true;
            document.body.classList.add('overflow-hidden');
            this.setTab(tab);
        },

        setTab(tab) {
            this.tab = tab;
            if (tab === 'products' && !this.productsLoaded) {
                this.productsLoaded = true;
                document.body.dispatchEvent(new CustomEvent('priboi:load-modal-products'));
            }
        },

        hide() {
            this.open = false;
            this.prefill = {};
            document.body.classList.remove('overflow-hidden');
        },
    });

    Alpine.store('toast', {
        items: [],

        push(message, kind = 'info', ttl = 3500) {
            const id = Date.now() + Math.random();
            this.items.push({ id, message, kind });
            setTimeout(() => this.dismiss(id), ttl);
        },

        dismiss(id) {
            this.items = this.items.filter(t => t.id !== id);
        },
    });

    Alpine.data('dropdown', () => ({
        open: false,
        toggle() { this.open = !this.open; },
        close() { this.open = false; },
    }));

    Alpine.data('bookingForm', () => ({
        guests: 2,
        duration: 2,
        minDate: new Date().toISOString().split('T')[0],

        init() {
            this.$watch('$store.modal.prefill', (prefill) => {
                if (prefill && prefill.table) {
                    this.$nextTick(() => {
                        const select = this.$refs.tableSelect;
                        if (select) select.value = prefill.table;
                    });
                }
            });
        },
    }));
});

document.body.addEventListener('htmx:configRequest', (event) => {
    const tokenInput = document.querySelector('input[name="csrfmiddlewaretoken"]');
    if (tokenInput) {
        event.detail.headers['X-CSRFToken'] = tokenInput.value;
    } else {
        const cookieToken = document.cookie.split('; ')
            .find(row => row.startsWith('csrftoken='));
        if (cookieToken) {
            event.detail.headers['X-CSRFToken'] = cookieToken.split('=')[1];
        }
    }
});

document.body.addEventListener('htmx:responseError', () => {
    if (window.Alpine && Alpine.store('toast')) {
        Alpine.store('toast').push('Ошибка соединения. Попробуйте ещё раз.', 'error');
    }
});

document.body.addEventListener('priboi:toast', (event) => {
    const { message, kind } = event.detail || {};
    if (message && window.Alpine && Alpine.store('toast')) {
        Alpine.store('toast').push(message, kind || 'info');
    }
});

document.body.addEventListener('priboi:cart-clear', () => {
    if (window.Alpine && Alpine.store('cart')) {
        Alpine.store('cart').clear();
    }
});

document.body.addEventListener('priboi:modal-close', () => {
    if (window.Alpine && Alpine.store('modal')) {
        Alpine.store('modal').hide();
    }
});

function initFlatpickr(scope) {
    scope = scope || document;
    if (!window.flatpickr) return;
    if (flatpickr.l10ns && flatpickr.l10ns.ru) {
        flatpickr.localize(flatpickr.l10ns.ru);
    }
    scope.querySelectorAll('input[type="date"]:not([data-fp-init]), input[type="time"]:not([data-fp-init])').forEach((el) => {
        el.setAttribute('data-fp-init', '1');
        const baseClass = el.className;
        const inModal = !!el.closest('.modal-panel');
        const opts = el.type === 'time'
            ? {
                enableTime: true, noCalendar: true, time_24hr: true,
                dateFormat: 'H:i', altInput: true, altFormat: 'H:i',
                altInputClass: baseClass + ' fp-display',
                static: inModal,
            }
            : {
                dateFormat: 'Y-m-d', minDate: 'today',
                altInput: true, altFormat: 'd.m.Y',
                altInputClass: baseClass + ' fp-display',
                static: inModal,
            };
        flatpickr(el, opts);
    });
}

function initTomSelect(scope) {
    scope = scope || document;
    if (!window.TomSelect) return;
    scope.querySelectorAll('select.select:not([data-ts-init])').forEach((el) => {
        el.setAttribute('data-ts-init', '1');
        new TomSelect(el, {
            create: false,
            allowEmptyOption: true,
            controlInput: null,
        });
    });
}

function scrollKey() {
    return 'priboi:scroll:' + window.location.pathname + window.location.search;
}

if ('scrollRestoration' in history) {
    history.scrollRestoration = 'manual';
}

let scrollSaveTimer;
window.addEventListener('scroll', () => {
    clearTimeout(scrollSaveTimer);
    scrollSaveTimer = setTimeout(() => {
        sessionStorage.setItem(scrollKey(), String(window.scrollY));
    }, 150);
}, { passive: true });

function restoreScroll() {
    const saved = sessionStorage.getItem(scrollKey());
    const y = saved ? parseInt(saved, 10) : 0;
    window.scrollTo({ top: y, behavior: 'instant' });
}

document.body.addEventListener('htmx:afterSettle', (event) => {
    if (event.detail && event.detail.target && event.detail.target.id === 'main-content') {
        restoreScroll();
    }
    updateActiveNav();
    initFlatpickr(event.detail && event.detail.target);
    initTomSelect(event.detail && event.detail.target);
});

function updateActiveNav() {
    const path = window.location.pathname;
    document.querySelectorAll('[data-nav]').forEach(link => {
        const target = link.getAttribute('data-nav');
        const isActive = target === '/'
            ? path === '/'
            : path === target || path.startsWith(target);
        link.classList.toggle('active', isActive);
    });
}

let revealObserver = null;
function initReveal(scope) {
    scope = scope || document;
    if (!('IntersectionObserver' in window)) {
        scope.querySelectorAll('.reveal').forEach((el) => el.classList.add('in-view'));
        return;
    }
    if (!revealObserver) {
        revealObserver = new IntersectionObserver((entries) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('in-view');
                    revealObserver.unobserve(entry.target);
                }
            });
        }, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 });
    }
    scope.querySelectorAll('.reveal:not(.in-view)').forEach((el) => revealObserver.observe(el));
}

document.body.addEventListener('htmx:afterSettle', (event) => {
    initReveal(event.detail && event.detail.target);
});

document.addEventListener('DOMContentLoaded', () => {
    updateActiveNav();
    restoreScroll();
    initFlatpickr();
    initTomSelect();
    initReveal();
});

window.addEventListener('load', () => {
    initFlatpickr();
    initTomSelect();
    initReveal();
});
