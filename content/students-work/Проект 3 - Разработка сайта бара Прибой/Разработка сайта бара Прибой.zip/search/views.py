from django.shortcuts import redirect, render
from django.views.decorators.http import require_GET

from catalog.models import Hookah, Service


def _service_haystack(service):
    parts = [service.name or '', service.description or '']
    if service.category_id:
        parts.append(service.category.name or '')
    parts.extend(t.name for t in service.tags.all())
    return ' '.join(parts).lower()


def _services_qs(query):
    qs = Service.objects.select_related('category').prefetch_related('images', 'tags').filter(
        is_available=True,
    )
    query = (query or '').strip().lower()
    if not query:
        return list(qs)
    return [s for s in qs if query in _service_haystack(s)]


def _hookahs_qs(query):
    qs = Hookah.objects.filter(is_available=True)
    query = (query or '').strip().lower()
    if not query:
        return list(qs)
    return [
        h for h in qs
        if query in (h.name or '').lower() or query in (h.description or '').lower()
    ]


@require_GET
def search(request):
    if not getattr(request, 'htmx', None):
        return redirect('catalog:index')

    query = request.GET.get('q', '').strip()

    if not query:
        return render(request, 'search/results.html', {
            'query': '',
            'services': [],
            'tables': [],
            'hookahs': [],
        })

    return render(request, 'search/results.html', {
        'query': query,
        'services': _services_qs(query)[:12],
        'tables': [],
        'hookahs': _hookahs_qs(query)[:6],
    })


@require_GET
def modal_search(request):
    if not getattr(request, 'htmx', None):
        return redirect('catalog:index')

    query = request.GET.get('q', '').strip()
    services = _services_qs(query)[:15]
    return render(request, 'search/modal_results.html', {
        'services': services,
        'query': query,
    })
