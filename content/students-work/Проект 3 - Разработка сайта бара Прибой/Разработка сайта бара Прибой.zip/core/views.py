from django.shortcuts import render

from catalog.models import Promotion, Service


def home(request):
    promotions = Promotion.objects.filter(is_active=True).order_by('-start_date')[:3]
    popular_services = (
        Service.objects.filter(is_available=True)
        .select_related('category')
        .prefetch_related('images')
        .order_by('-created_at')[:8]
    )
    return render(request, 'core/home.html', {
        'promotions': promotions,
        'popular_services': popular_services,
    })
