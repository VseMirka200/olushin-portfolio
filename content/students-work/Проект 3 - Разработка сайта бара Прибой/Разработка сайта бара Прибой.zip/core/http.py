import json

from django.http import HttpResponse
from django.shortcuts import redirect


def htmx_location(request, url, target='#main-content'):
    if not getattr(request, 'htmx', None):
        return redirect(url)
    response = HttpResponse(status=204)
    response['HX-Location'] = json.dumps({
        'path': url,
        'target': target,
        'select': '#main-content',
        'swap': 'innerHTML show:window:top',
    })
    return response


def htmx_redirect(request, url):
    if not getattr(request, 'htmx', None):
        return redirect(url)
    response = HttpResponse(status=204)
    response['HX-Redirect'] = url
    return response
