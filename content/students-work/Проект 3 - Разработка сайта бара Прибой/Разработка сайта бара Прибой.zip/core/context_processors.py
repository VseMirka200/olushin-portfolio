from catalog.models import Table, Hookah


def shared_modal_data(request):
    return {
        'available_tables': Table.objects.filter(is_active=True, status='free').order_by('number'),
        'available_hookahs': Hookah.objects.filter(is_available=True).order_by('name'),
    }
