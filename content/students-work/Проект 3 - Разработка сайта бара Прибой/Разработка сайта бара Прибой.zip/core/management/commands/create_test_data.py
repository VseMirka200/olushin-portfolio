from datetime import timedelta

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand
from django.utils import timezone

from catalog.models import Category, Hookah, Promotion, Service, Table, Tag

User = get_user_model()


class Command(BaseCommand):
    help = 'Создание тестовых данных на русском (опция --reset очищает каталог перед заполнением)'

    def add_arguments(self, parser):
        parser.add_argument(
            '--reset', action='store_true',
            help='Удалить старые позиции каталога перед заполнением',
        )

    def handle(self, *args, **options):
        if options['reset']:
            self.stdout.write('Очищаю старые данные каталога...')
            Service.objects.all().delete()
            Tag.objects.all().delete()
            Category.objects.all().delete()
            Hookah.objects.all().delete()
            Table.objects.all().delete()
            Promotion.objects.all().delete()

        self._create_users()
        self._create_categories()
        self._create_tags()
        self._create_services()
        self._create_tables()
        self._create_hookahs()
        self._create_promotion()

        self.stdout.write(self.style.SUCCESS('Готово. Учётные записи:'))
        self.stdout.write('  admin@priboi.local / admin123')
        self.stdout.write('  user@test.com / user123')

    def _create_users(self):
        if not User.objects.filter(email='admin@priboi.local').exists():
            User.objects.create_superuser(
                username='admin',
                email='admin@priboi.local',
                password='admin123',
                first_name='Администратор',
                last_name='Прибой',
                is_verified=True,
            )
        if not User.objects.filter(email='user@test.com').exists():
            User.objects.create_user(
                username='user@test.com',
                email='user@test.com',
                password='user123',
                first_name='Иван',
                last_name='Иванов',
                phone='+79991234567',
                is_verified=True,
            )

    def _create_categories(self):
        for data in (
            {'slug': 'bar', 'name': 'Бар', 'order': 1, 'description': 'Коктейли и напитки'},
            {'slug': 'kitchen', 'name': 'Кухня', 'order': 2, 'description': 'Закуски и горячее'},
        ):
            Category.objects.update_or_create(slug=data['slug'], defaults=data)

    def _create_tags(self):
        for name in ('популярное', 'новинка', 'акция', 'острое', 'вегетарианское', 'алкогольное'):
            Tag.objects.get_or_create(name=name, defaults={'slug': name})

    def _create_services(self):
        bar = Category.objects.get(slug='bar')
        kitchen = Category.objects.get(slug='kitchen')
        services = (
            {'slug': 'mohito',       'name': 'Мохито',           'category': bar,     'price': 350, 'description': 'Освежающий коктейль с мятой и лаймом'},
            {'slug': 'pina-colada',  'name': 'Пина Колада',      'category': bar,     'price': 400, 'description': 'Тропический коктейль с кокосом и ананасом'},
            {'slug': 'margarita',    'name': 'Маргарита',        'category': bar,     'price': 380, 'description': 'Классика на текиле с солью'},
            {'slug': 'espresso',     'name': 'Эспрессо',         'category': bar,     'price': 150, 'description': 'Крепкий итальянский кофе'},
            {'slug': 'cappuccino',   'name': 'Капучино',         'category': bar,     'price': 200, 'description': 'С плотной молочной пенкой'},
            {'slug': 'caesar',       'name': 'Цезарь с курицей', 'category': kitchen, 'price': 450, 'description': 'Классический салат с пармезаном'},
            {'slug': 'greek',        'name': 'Греческий салат',  'category': kitchen, 'price': 380, 'description': 'Свежие овощи с фетой'},
            {'slug': 'tom-yam',      'name': 'Том Ям',           'category': kitchen, 'price': 520, 'description': 'Острый тайский суп с морепродуктами'},
            {'slug': 'salmon-steak', 'name': 'Стейк из лосося',  'category': kitchen, 'price': 680, 'description': 'С овощами гриль'},
            {'slug': 'carbonara',    'name': 'Паста Карбонара',  'category': kitchen, 'price': 480, 'description': 'С беконом и сливочным соусом'},
        )
        for data in services:
            Service.objects.update_or_create(slug=data['slug'], defaults=data)

    def _create_tables(self):
        rows = (
            {'number': '1',     'capacity': 2,  'status': 'free'},
            {'number': '2',     'capacity': 4,  'status': 'free'},
            {'number': '3',     'capacity': 4,  'status': 'occupied',
             'occupied_until': timezone.now() + timedelta(hours=2)},
            {'number': '4',     'capacity': 6,  'status': 'free'},
            {'number': '5',     'capacity': 8,  'status': 'free'},
            {'number': 'VIP-1', 'capacity': 10, 'status': 'free',
             'description': 'VIP-зона с панорамным видом'},
        )
        for data in rows:
            Table.objects.update_or_create(number=data['number'], defaults=data)

    def _create_hookahs(self):
        rows = (
            {'name': 'Двойное яблоко', 'price': 800, 'description': 'Классический вкус'},
            {'name': 'Мята',           'price': 750, 'description': 'Освежающий микс'},
            {'name': 'Виноград',       'price': 850, 'description': 'Сладкий виноградный вкус'},
            {'name': 'Арбуз',          'price': 800, 'description': 'Летний освежающий вкус'},
        )
        for data in rows:
            Hookah.objects.update_or_create(name=data['name'], defaults=data)

    def _create_promotion(self):
        Promotion.objects.update_or_create(
            title='Счастливые часы',
            defaults={
                'description': 'Скидка 20% на все коктейли с 14:00 до 17:00',
                'discount_percent': 20,
                'start_date': timezone.now(),
                'end_date': timezone.now() + timedelta(days=30),
                'is_active': True,
            },
        )
