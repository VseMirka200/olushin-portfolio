from django.db import models
from django.conf import settings
from django.core.validators import MinValueValidator
from catalog.models import Table, Hookah


class Booking(models.Model):
    """Бронирование столика"""

    STATUS_CHOICES = [
        ('pending', 'Ожидает подтверждения'),
        ('confirmed', 'Подтверждено'),
        ('cancelled', 'Отменено'),
        ('completed', 'Завершено'),
    ]

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='bookings', verbose_name='Пользователь')
    table = models.ForeignKey(Table, on_delete=models.CASCADE, related_name='bookings', verbose_name='Стол')
    date = models.DateField('Дата')
    time = models.TimeField('Время')
    guests_count = models.PositiveIntegerField('Количество гостей', validators=[MinValueValidator(1)])
    duration_hours = models.PositiveIntegerField('Длительность (часов)', default=2, validators=[MinValueValidator(1)])
    comment = models.TextField('Комментарий', blank=True)
    status = models.CharField('Статус', max_length=20, choices=STATUS_CHOICES, default='pending')
    hookah = models.ForeignKey(Hookah, on_delete=models.SET_NULL, null=True, blank=True, related_name='bookings', verbose_name='Кальян')
    created_at = models.DateTimeField('Создано', auto_now_add=True)
    updated_at = models.DateTimeField('Обновлено', auto_now=True)

    class Meta:
        verbose_name = 'Бронирование'
        verbose_name_plural = 'Бронирования'
        ordering = ['-date', '-time']

    def __str__(self):
        return f"Бронь {self.table.number} на {self.date} {self.time} ({self.user.get_full_name()})"


class Order(models.Model):
    """Предзаказ продуктов"""

    STATUS_CHOICES = [
        ('pending', 'Ожидает подтверждения'),
        ('confirmed', 'Подтверждено'),
        ('preparing', 'Готовится'),
        ('ready', 'Готово к выдаче'),
        ('completed', 'Выдано'),
        ('cancelled', 'Отменено'),
    ]

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='orders', verbose_name='Пользователь')
    pickup_date = models.DateField('Дата получения')
    pickup_time = models.TimeField('Время получения')
    comment = models.TextField('Комментарий', blank=True)
    status = models.CharField('Статус', max_length=20, choices=STATUS_CHOICES, default='pending')
    total_amount = models.DecimalField('Общая сумма', max_digits=10, decimal_places=2, default=0)
    created_at = models.DateTimeField('Создано', auto_now_add=True)
    updated_at = models.DateTimeField('Обновлено', auto_now=True)

    class Meta:
        verbose_name = 'Предзаказ'
        verbose_name_plural = 'Предзаказы'
        ordering = ['-created_at']

    def __str__(self):
        return f"Заказ #{self.id} от {self.user.get_full_name()} на {self.pickup_date}"

    def calculate_total(self):
        """Рассчитать общую сумму заказа"""
        total = sum(item.subtotal for item in self.items.all())
        self.total_amount = total
        self.save()
        return total


class OrderItem(models.Model):
    """Позиция предзаказа"""

    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='items', verbose_name='Заказ')
    service = models.ForeignKey('catalog.Service', on_delete=models.CASCADE, verbose_name='Услуга')
    quantity = models.PositiveIntegerField('Количество', validators=[MinValueValidator(1)])
    price = models.DecimalField('Цена', max_digits=10, decimal_places=2)

    class Meta:
        verbose_name = 'Позиция заказа'
        verbose_name_plural = 'Позиции заказа'

    def __str__(self):
        return f"{self.service.name} x{self.quantity}"

    @property
    def subtotal(self):
        """Подытог для позиции"""
        return self.price * self.quantity

    def save(self, *args, **kwargs):
        if not self.price:
            self.price = self.service.price
        super().save(*args, **kwargs)


class Review(models.Model):
    """Отзывы"""

    RATING_CHOICES = [(i, str(i)) for i in range(1, 6)]

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='reviews', verbose_name='Пользователь')
    service = models.ForeignKey('catalog.Service', on_delete=models.CASCADE, related_name='reviews', verbose_name='Услуга', null=True, blank=True)
    booking = models.ForeignKey(Booking, on_delete=models.CASCADE, related_name='reviews', verbose_name='Бронирование', null=True, blank=True)
    rating = models.PositiveIntegerField('Рейтинг', choices=RATING_CHOICES)
    text = models.TextField('Текст отзыва')
    is_moderated = models.BooleanField('Модерирован', default=False)
    is_approved = models.BooleanField('Одобрен', default=False)
    created_at = models.DateTimeField('Создано', auto_now_add=True)

    class Meta:
        verbose_name = 'Отзыв'
        verbose_name_plural = 'Отзывы'
        ordering = ['-created_at']

    def __str__(self):
        return f"Отзыв от {self.user.get_full_name()} - {self.rating}/5"

