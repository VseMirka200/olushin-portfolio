from django.urls import path

from . import views

app_name = 'bookings'

urlpatterns = [
    path('order/create/', views.create_order, name='create_order'),
    path('order/<int:order_id>/cancel/', views.cancel_order, name='cancel_order'),
    path('booking/create/', views.create_booking, name='create_booking'),
]
