from django.contrib import admin
from .models import Booking, Order, OrderItem, Review


class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 1
    fields = ['service', 'quantity', 'price']
    readonly_fields = ['price']


@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ['id', 'user', 'table', 'date', 'time', 'guests_count', 'status', 'hookah', 'created_at']
    list_filter = ['status', 'date', 'created_at']
    search_fields = ['user__email', 'user__first_name', 'user__last_name', 'table__number']
    date_hierarchy = 'date'
    list_editable = ['status']
    readonly_fields = ['created_at', 'updated_at']

    actions = ['approve_bookings', 'cancel_bookings']

    def approve_bookings(self, request, queryset):
        queryset.update(status='confirmed')
        self.message_user(request, f"Одобрено бронирований: {queryset.count()}")
    approve_bookings.short_description = "Одобрить выбранные бронирования"

    def cancel_bookings(self, request, queryset):
        queryset.update(status='cancelled')
        self.message_user(request, f"Отменено бронирований: {queryset.count()}")
    cancel_bookings.short_description = "Отменить выбранные бронирования"


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ['id', 'user', 'pickup_date', 'pickup_time', 'status', 'total_amount', 'created_at']
    list_filter = ['status', 'pickup_date', 'created_at']
    search_fields = ['user__email', 'user__first_name', 'user__last_name']
    date_hierarchy = 'pickup_date'
    list_editable = ['status']
    readonly_fields = ['created_at', 'updated_at', 'total_amount']
    inlines = [OrderItemInline]

    actions = ['confirm_orders', 'mark_ready']

    def confirm_orders(self, request, queryset):
        queryset.update(status='confirmed')
        self.message_user(request, f"Подтверждено заказов: {queryset.count()}")
    confirm_orders.short_description = "Подтвердить выбранные заказы"

    def mark_ready(self, request, queryset):
        queryset.update(status='ready')
        self.message_user(request, f"Отмечено готовыми: {queryset.count()}")
    mark_ready.short_description = "Отметить как готовые к выдаче"


@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ['id', 'user', 'service', 'rating', 'is_approved', 'created_at']
    list_filter = ['rating', 'is_approved', 'is_moderated', 'created_at']
    search_fields = ['user__email', 'user__first_name', 'user__last_name', 'text']
    date_hierarchy = 'created_at'
    list_editable = ['is_approved']
    readonly_fields = ['created_at']

    actions = ['approve_reviews', 'reject_reviews']

    def approve_reviews(self, request, queryset):
        queryset.update(is_moderated=True, is_approved=True)
        self.message_user(request, f"Одобрено отзывов: {queryset.count()}")
    approve_reviews.short_description = "Одобрить выбранные отзывы"

    def reject_reviews(self, request, queryset):
        queryset.update(is_moderated=True, is_approved=False)
        self.message_user(request, f"Отклонено отзывов: {queryset.count()}")
    reject_reviews.short_description = "Отклонить выбранные отзывы"

