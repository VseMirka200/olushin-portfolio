from django import forms
from django.core.exceptions import ValidationError
from django.utils import timezone
from datetime import datetime, timedelta, date

from catalog.models import Table, Hookah, Service
from .models import Booking


class BookingForm(forms.Form):
    table_id = forms.IntegerField(min_value=1)
    booking_date = forms.DateField()
    booking_time = forms.TimeField()
    guests_count = forms.IntegerField(min_value=1, max_value=50)
    duration_hours = forms.IntegerField(min_value=1, max_value=8, initial=2)
    hookah_id = forms.IntegerField(min_value=1, required=False)
    comment = forms.CharField(max_length=500, required=False)

    def clean_table_id(self):
        table_id = self.cleaned_data['table_id']
        try:
            self.table = Table.objects.get(pk=table_id, is_active=True)
        except Table.DoesNotExist:
            raise ValidationError('Стол не найден или недоступен')
        return table_id

    def clean_hookah_id(self):
        hookah_id = self.cleaned_data.get('hookah_id')
        if not hookah_id:
            self.hookah = None
            return None
        try:
            self.hookah = Hookah.objects.get(pk=hookah_id, is_available=True)
        except Hookah.DoesNotExist:
            raise ValidationError('Кальян недоступен')
        return hookah_id

    def clean(self):
        data = super().clean()
        booking_date = data.get('booking_date')
        booking_time = data.get('booking_time')
        guests = data.get('guests_count')
        duration = data.get('duration_hours')
        table = getattr(self, 'table', None)

        if booking_date and booking_time:
            naive = datetime.combine(booking_date, booking_time)
            aware = timezone.make_aware(naive)
            if aware <= timezone.now():
                raise ValidationError('Время бронирования должно быть в будущем')
            self.start_dt = aware
            if duration:
                self.end_dt = aware + timedelta(hours=duration)

        if table and guests and guests > table.capacity:
            raise ValidationError(f'Стол вмещает максимум {table.capacity} человек')

        if table and booking_date:
            conflict = Booking.objects.filter(
                table=table,
                status__in=['pending', 'confirmed'],
                date=booking_date,
            ).exists()
            if conflict:
                raise ValidationError('Стол уже занят на эту дату')

        return data


class OrderForm(forms.Form):
    pickup_date = forms.DateField()
    pickup_time = forms.TimeField()

    def __init__(self, *args, cart_items=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.cart_items = cart_items or []
        self.resolved_items = []

    def clean(self):
        data = super().clean()
        pickup_date = data.get('pickup_date')
        pickup_time = data.get('pickup_time')

        if not self.cart_items:
            raise ValidationError('Корзина пуста')

        if pickup_date and pickup_time:
            naive = datetime.combine(pickup_date, pickup_time)
            aware = timezone.make_aware(naive)
            if aware <= timezone.now():
                raise ValidationError('Время получения должно быть в будущем')
            self.pickup_dt = aware

        service_ids = []
        for item in self.cart_items:
            try:
                sid = int(item.get('id'))
                qty = int(item.get('quantity', 0))
            except (TypeError, ValueError):
                raise ValidationError('Некорректный формат корзины')
            if qty < 1 or qty > 99:
                raise ValidationError('Количество должно быть от 1 до 99')
            service_ids.append((sid, qty))

        services = {s.pk: s for s in Service.objects.filter(
            pk__in=[sid for sid, _ in service_ids], is_available=True
        )}

        for sid, qty in service_ids:
            service = services.get(sid)
            if not service:
                raise ValidationError('Один из товаров недоступен')
            self.resolved_items.append((service, qty))

        return data
