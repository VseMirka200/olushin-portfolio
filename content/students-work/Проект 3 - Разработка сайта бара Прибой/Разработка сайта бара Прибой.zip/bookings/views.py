import json

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from django.template.loader import render_to_string
from django.urls import reverse
from django.views.decorators.http import require_POST

from core.http import htmx_location
from .forms import BookingForm, OrderForm
from .models import Booking, Order, OrderItem


def _hx_error(errors):
    html = render_to_string('components/form_errors.html', {'errors': errors})
    return HttpResponse(html, status=400)


@login_required
@require_POST
def create_order(request):
    raw_cart = request.POST.get('cart', '[]')
    try:
        cart_items = json.loads(raw_cart)
    except json.JSONDecodeError:
        return _hx_error(['Некорректный формат корзины'])

    form = OrderForm(request.POST, cart_items=cart_items)
    if not form.is_valid():
        return _hx_error([str(e) for errs in form.errors.values() for e in errs])

    with transaction.atomic():
        order = Order.objects.create(
            user=request.user,
            pickup_date=form.cleaned_data['pickup_date'],
            pickup_time=form.cleaned_data['pickup_time'],
            status='pending',
        )
        for service, qty in form.resolved_items:
            OrderItem.objects.create(
                order=order,
                service=service,
                quantity=qty,
                price=service.price,
            )
        order.calculate_total()

    response = htmx_location(request, reverse('accounts:profile'))
    response['HX-Trigger'] = json.dumps({
        'priboi:toast': {'message': 'Заказ оформлен', 'kind': 'success'},
        'priboi:cart-clear': True,
        'priboi:modal-close': True,
    })
    return response


@login_required
@require_POST
def create_booking(request):
    form = BookingForm(request.POST)
    if not form.is_valid():
        return _hx_error([str(e) for errs in form.errors.values() for e in errs])

    with transaction.atomic():
        booking = Booking.objects.create(
            user=request.user,
            table=form.table,
            date=form.cleaned_data['booking_date'],
            time=form.cleaned_data['booking_time'],
            guests_count=form.cleaned_data['guests_count'],
            duration_hours=form.cleaned_data['duration_hours'],
            hookah=form.hookah,
            comment=form.cleaned_data.get('comment', ''),
            status='confirmed',
        )
        table = form.table
        table.status = 'reserved'
        table.occupied_until = form.end_dt
        table.save(update_fields=['status', 'occupied_until'])

    response = htmx_location(request, reverse('accounts:profile'))
    response['HX-Trigger'] = json.dumps({
        'priboi:toast': {'message': 'Стол забронирован', 'kind': 'success'},
        'priboi:modal-close': True,
    })
    return response


@login_required
@require_POST
def cancel_order(request, order_id):
    order = get_object_or_404(Order, pk=order_id, user=request.user)
    if order.status not in ('pending', 'confirmed'):
        messages.error(request, 'Этот заказ нельзя отменить')
    else:
        order.status = 'cancelled'
        order.save(update_fields=['status'])
        messages.success(request, 'Заказ отменён')
    return htmx_location(request, reverse('accounts:profile'))


