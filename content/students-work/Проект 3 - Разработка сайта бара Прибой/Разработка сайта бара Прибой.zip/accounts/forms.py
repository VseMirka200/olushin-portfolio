from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.core.exceptions import ValidationError
from .models import User
import re

RU_NAME_RE = re.compile(r'^[А-ЯЁ][а-яё]+(?:[\s\-][А-ЯЁа-яё]+)*$')


def _normalize_ru_phone(raw):
    """Приводит ввод к виду +7XXXXXXXXXX или бросает ValidationError."""
    raw = (raw or '').strip()
    if not raw:
        raise ValidationError('Номер телефона обязателен')
    digits = re.sub(r'\D', '', raw)
    if len(digits) == 11 and digits.startswith('8'):
        digits = '7' + digits[1:]
    if len(digits) == 10 and digits.startswith('9'):
        digits = '7' + digits
    if len(digits) != 11 or not digits.startswith('7'):
        raise ValidationError('Введите российский номер: +7 9XX XXX-XX-XX')
    if digits[1] != '9':
        raise ValidationError('Поддерживаются только мобильные номера (+7 9XX...)')
    return '+' + digits


def _clean_ru_name(value, label):
    name = (value or '').strip()
    if not name:
        raise ValidationError(f'{label} обязательно')
    if len(name) < 2:
        raise ValidationError(f'{label} слишком короткое')
    if len(name) > 50:
        raise ValidationError(f'{label} слишком длинное')
    if not RU_NAME_RE.match(name):
        raise ValidationError(f'{label} должно содержать только русские буквы')
    return name


class RegisterForm(UserCreationForm):
    """Форма регистрации"""

    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={'class': 'input', 'placeholder': 'Email'})
    )
    first_name = forms.CharField(
        max_length=50,
        required=True,
        widget=forms.TextInput(attrs={'class': 'input', 'placeholder': 'Иван'})
    )
    last_name = forms.CharField(
        max_length=50,
        required=True,
        widget=forms.TextInput(attrs={'class': 'input', 'placeholder': 'Иванов'})
    )
    phone = forms.CharField(
        max_length=20,
        required=True,
        widget=forms.TextInput(attrs={'class': 'input', 'placeholder': '+7 (999) 999-99-99'})
    )
    password1 = forms.CharField(
        label='Пароль',
        widget=forms.PasswordInput(attrs={'class': 'input', 'placeholder': 'Пароль'})
    )
    password2 = forms.CharField(
        label='Подтверждение пароля',
        widget=forms.PasswordInput(attrs={'class': 'input', 'placeholder': 'Повторите пароль'})
    )

    class Meta:
        model = User
        fields = ['email', 'first_name', 'last_name', 'phone', 'password1', 'password2']

    def clean_password1(self):
        password = self.cleaned_data.get('password1')

        if len(password) < 8:
            raise ValidationError('Пароль должен содержать минимум 8 символов')

        if not re.search(r'[A-Za-z]', password):
            raise ValidationError('Пароль должен содержать хотя бы одну букву')

        if not re.search(r'\d', password):
            raise ValidationError('Пароль должен содержать хотя бы одну цифру')

        return password

    def clean_email(self):
        email = self.cleaned_data.get('email')
        User.objects.filter(email=email, is_verified=False).delete()
        if User.objects.filter(email=email).exists():
            raise ValidationError('Пользователь с таким email уже существует')
        return email

    def clean_first_name(self):
        return _clean_ru_name(self.cleaned_data.get('first_name'), 'Имя')

    def clean_last_name(self):
        return _clean_ru_name(self.cleaned_data.get('last_name'), 'Фамилия')

    def clean_phone(self):
        return _normalize_ru_phone(self.cleaned_data.get('phone'))


class LoginForm(forms.Form):
    """Форма входа"""

    email = forms.EmailField(
        widget=forms.EmailInput(attrs={'class': 'input', 'placeholder': 'Email'})
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'input', 'placeholder': 'Пароль'})
    )


class VerificationCodeForm(forms.Form):
    """Форма ввода кода подтверждения"""

    code = forms.CharField(
        max_length=6,
        min_length=6,
        widget=forms.TextInput(attrs={
            'class': 'input text-center text-2xl tracking-widest',
            'placeholder': '000000',
            'maxlength': '6'
        })
    )


class PasswordResetRequestForm(forms.Form):
    """Форма запроса восстановления пароля"""

    email = forms.EmailField(
        widget=forms.EmailInput(attrs={'class': 'input', 'placeholder': 'Email'})
    )


class PasswordResetForm(forms.Form):
    """Форма установки нового пароля"""

    code = forms.CharField(
        max_length=6,
        widget=forms.TextInput(attrs={'class': 'input', 'placeholder': 'Код из письма'})
    )
    password1 = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'input', 'placeholder': 'Новый пароль'})
    )
    password2 = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'input', 'placeholder': 'Повторите пароль'})
    )

    def clean_password1(self):
        password = self.cleaned_data.get('password1')

        if len(password) < 8:
            raise ValidationError('Пароль должен содержать минимум 8 символов')

        if not re.search(r'[A-Za-z]', password):
            raise ValidationError('Пароль должен содержать хотя бы одну букву')

        if not re.search(r'\d', password):
            raise ValidationError('Пароль должен содержать хотя бы одну цифру')

        return password

    def clean(self):
        cleaned_data = super().clean()
        password1 = cleaned_data.get('password1')
        password2 = cleaned_data.get('password2')

        if password1 and password2 and password1 != password2:
            raise ValidationError('Пароли не совпадают')

        return cleaned_data
