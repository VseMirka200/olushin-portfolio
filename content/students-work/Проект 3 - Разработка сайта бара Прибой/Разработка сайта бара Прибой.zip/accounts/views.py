from datetime import datetime, timedelta

from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.hashers import make_password
from django.shortcuts import get_object_or_404, render
from django.urls import reverse
from django.utils import timezone
from django.views.decorators.http import require_POST

from bookings.models import Booking, Order
from core.http import htmx_location, htmx_redirect
from .forms import (
    LoginForm,
    PasswordResetForm,
    PasswordResetRequestForm,
    RegisterForm,
    VerificationCodeForm,
)
from .models import User
from .utils import (
    CODE_TTL_MINUTES,
    generate_code,
    send_password_reset_email,
    send_verification_code,
    verify_password_reset_code,
)


def _build_pending(form):
    return {
        'email': form.cleaned_data['email'],
        'first_name': form.cleaned_data['first_name'],
        'last_name': form.cleaned_data['last_name'],
        'phone': form.cleaned_data.get('phone', ''),
        'password_hash': make_password(form.cleaned_data['password1']),
        'code': generate_code(),
        'expires_at': (timezone.now() + timedelta(minutes=CODE_TTL_MINUTES)).isoformat(),
    }


def register(request):
    if request.user.is_authenticated:
        return htmx_redirect(request, reverse('core:home'))

    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            pending = _build_pending(form)
            request.session['pending_registration'] = pending
            send_verification_code(pending['email'], pending['first_name'], pending['code'])
            messages.success(request, 'Код подтверждения отправлен на email')
            return htmx_redirect(request, reverse('accounts:verify_email'))
    else:
        form = RegisterForm()

    return render(request, 'accounts/register.html', {'form': form})


def verify_email(request):
    pending = request.session.get('pending_registration')
    if not pending:
        return htmx_redirect(request, reverse('accounts:register'))

    if request.method == 'POST':
        form = VerificationCodeForm(request.POST)
        if form.is_valid():
            entered = form.cleaned_data['code']
            try:
                expires_at = datetime.fromisoformat(pending['expires_at'])
            except (TypeError, ValueError):
                expires_at = timezone.now()

            if expires_at < timezone.now():
                messages.error(request, 'Код истёк, отправьте новый')
            elif entered != pending['code']:
                messages.error(request, 'Неверный код')
            elif User.objects.filter(email=pending['email'], is_verified=True).exists():
                messages.error(request, 'Пользователь с таким email уже зарегистрирован')
                request.session.pop('pending_registration', None)
            else:
                User.objects.filter(email=pending['email'], is_verified=False).delete()
                user = User.objects.create(
                    username=pending['email'],
                    email=pending['email'],
                    first_name=pending['first_name'],
                    last_name=pending['last_name'],
                    phone=pending['phone'],
                    password=pending['password_hash'],
                    is_verified=True,
                )
                login(request, user)
                request.session.pop('pending_registration', None)
                messages.success(request, 'Email подтверждён')
                return htmx_redirect(request, reverse('core:home'))
    else:
        form = VerificationCodeForm()

    return render(request, 'accounts/verify_email.html', {
        'form': form,
        'pending_email': pending['email'],
    })


@require_POST
def resend_verification(request):
    pending = request.session.get('pending_registration')
    if not pending:
        return htmx_redirect(request, reverse('accounts:register'))

    pending['code'] = generate_code()
    pending['expires_at'] = (timezone.now() + timedelta(minutes=CODE_TTL_MINUTES)).isoformat()
    request.session['pending_registration'] = pending
    send_verification_code(pending['email'], pending['first_name'], pending['code'])
    messages.success(request, 'Новый код подтверждения отправлен')
    return htmx_location(request, reverse('accounts:verify_email'))


def login_view(request):
    if request.user.is_authenticated:
        return htmx_redirect(request, reverse('core:home'))

    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            user = authenticate(
                request,
                username=form.cleaned_data['email'],
                password=form.cleaned_data['password'],
            )
            if user is None:
                messages.error(request, 'Неверный email или пароль')
            elif not user.is_verified:
                messages.error(request, 'Email не подтверждён. Проверьте почту.')
            else:
                login(request, user)
                messages.success(request, f'Добро пожаловать, {user.first_name}!')
                return htmx_redirect(request, reverse('core:home'))
    else:
        form = LoginForm()

    return render(request, 'accounts/login.html', {'form': form})


@require_POST
def logout_view(request):
    logout(request)
    messages.success(request, 'Вы вышли из системы')
    return htmx_redirect(request, reverse('core:home'))


def password_reset_request(request):
    if request.method == 'POST':
        form = PasswordResetRequestForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            try:
                user = User.objects.get(email=email)
            except User.DoesNotExist:
                messages.error(request, 'Пользователь с таким email не найден')
            else:
                send_password_reset_email(user)
                request.session['reset_user_id'] = user.id
                messages.success(request, 'Код восстановления отправлен на email')
                return htmx_redirect(request, reverse('accounts:password_reset'))
    else:
        form = PasswordResetRequestForm()

    return render(request, 'accounts/password_reset_request.html', {'form': form})


def password_reset(request):
    user_id = request.session.get('reset_user_id')
    if not user_id:
        return htmx_redirect(request, reverse('accounts:password_reset_request'))

    try:
        user = User.objects.get(pk=user_id)
    except User.DoesNotExist:
        return htmx_redirect(request, reverse('accounts:password_reset_request'))

    if request.method == 'POST':
        form = PasswordResetForm(request.POST)
        if form.is_valid():
            if verify_password_reset_code(user, form.cleaned_data['code']):
                user.set_password(form.cleaned_data['password1'])
                user.save()
                request.session.pop('reset_user_id', None)
                messages.success(request, 'Пароль обновлён')
                return htmx_redirect(request, reverse('accounts:login'))
            messages.error(request, 'Неверный или истёкший код')
    else:
        form = PasswordResetForm()

    return render(request, 'accounts/password_reset.html', {'form': form})


@login_required
def profile(request):
    today = timezone.now().date()
    base_bookings = Booking.objects.select_related('table', 'hookah').filter(user=request.user)
    base_orders = Order.objects.prefetch_related('items__service').filter(user=request.user)

    context = {
        'active_bookings': base_bookings.filter(
            status__in=['pending', 'confirmed'], date__gte=today
        ).order_by('date', 'time'),
        'active_orders': base_orders.filter(
            status__in=['pending', 'confirmed', 'preparing', 'ready']
        ).order_by('-created_at'),
        'booking_history': base_bookings.filter(
            status__in=['completed', 'cancelled']
        ).order_by('-date')[:10],
        'order_history': base_orders.filter(
            status__in=['completed', 'cancelled']
        ).order_by('-created_at')[:10],
    }
    return render(request, 'accounts/profile.html', context)


@login_required
def profile_edit(request):
    if request.method == 'POST':
        user = request.user
        user.first_name = request.POST.get('first_name', user.first_name).strip()[:150]
        user.last_name = request.POST.get('last_name', user.last_name).strip()[:150]
        user.phone = request.POST.get('phone', user.phone).strip()[:17]
        user.save(update_fields=['first_name', 'last_name', 'phone'])
        messages.success(request, 'Профиль обновлён')
        return htmx_location(request, reverse('accounts:profile'))

    return render(request, 'accounts/profile_edit.html')


@login_required
@require_POST
def extend_booking(request, booking_id):
    booking = get_object_or_404(Booking, pk=booking_id, user=request.user)

    if booking.status not in ('pending', 'confirmed'):
        messages.error(request, 'Эту бронь нельзя продлить')
    else:
        try:
            hours = max(1, min(int(request.POST.get('hours', 1)), 4))
        except (TypeError, ValueError):
            hours = 1
        if booking.duration_hours + hours > 8:
            messages.error(request, 'Превышена максимальная длительность брони (8 ч)')
        else:
            booking.duration_hours += hours
            booking.save(update_fields=['duration_hours'])
            messages.success(request, f'Бронь продлена на {hours} ч')

    return htmx_location(request, reverse('accounts:profile'))


@login_required
@require_POST
def cancel_booking(request, booking_id):
    booking = get_object_or_404(Booking, pk=booking_id, user=request.user)

    if booking.status not in ('pending', 'confirmed'):
        messages.error(request, 'Эту бронь нельзя отменить')
    else:
        booking.status = 'cancelled'
        booking.save(update_fields=['status'])
        table = booking.table
        if table.status == 'reserved':
            table.status = 'free'
            table.occupied_until = None
            table.save(update_fields=['status', 'occupied_until'])
        messages.success(request, 'Бронь отменена')

    return htmx_location(request, reverse('accounts:profile'))
