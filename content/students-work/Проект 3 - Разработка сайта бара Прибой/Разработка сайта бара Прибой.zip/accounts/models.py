from django.contrib.auth.models import AbstractUser
from django.db import models
from django.core.validators import RegexValidator


class User(AbstractUser):
    """Кастомная модель пользователя"""

    phone_regex = RegexValidator(
        regex=r'^\+?1?\d{9,15}$',
        message="Номер телефона должен быть в формате: '+999999999'. До 15 цифр."
    )

    phone = models.CharField(
        'Телефон',
        validators=[phone_regex],
        max_length=17,
        blank=True
    )
    birth_date = models.DateField('Дата рождения', null=True, blank=True)
    email = models.EmailField('Email', unique=True)
    is_verified = models.BooleanField('Email подтвержден', default=False)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username', 'first_name', 'last_name']

    class Meta:
        verbose_name = 'Пользователь'
        verbose_name_plural = 'Пользователи'

    def __str__(self):
        return f"{self.get_full_name()} ({self.email})"


class EmailVerification(models.Model):
    """Модель для хранения кодов подтверждения email"""

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='verifications')
    code = models.CharField('Код подтверждения', max_length=6)
    created_at = models.DateTimeField('Создан', auto_now_add=True)
    is_used = models.BooleanField('Использован', default=False)

    class Meta:
        verbose_name = 'Код подтверждения'
        verbose_name_plural = 'Коды подтверждения'
        ordering = ['-created_at']

    def __str__(self):
        return f"Код для {self.user.email}: {self.code}"


class PasswordReset(models.Model):
    """Модель для хранения кодов восстановления пароля"""

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='password_resets')
    code = models.CharField('Код восстановления', max_length=6)
    created_at = models.DateTimeField('Создан', auto_now_add=True)
    is_used = models.BooleanField('Использован', default=False)

    class Meta:
        verbose_name = 'Код восстановления пароля'
        verbose_name_plural = 'Коды восстановления пароля'
        ordering = ['-created_at']

    def __str__(self):
        return f"Код восстановления для {self.user.email}: {self.code}"

