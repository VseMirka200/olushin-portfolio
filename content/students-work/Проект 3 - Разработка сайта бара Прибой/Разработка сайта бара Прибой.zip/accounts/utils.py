import logging
import random
import string
from datetime import timedelta

from django.conf import settings
from django.core.mail import send_mail
from django.utils import timezone

from .models import EmailVerification, PasswordReset

logger = logging.getLogger(__name__)

CODE_TTL_MINUTES = 15


def generate_code(length=6):
    return ''.join(random.choices(string.digits, k=length))


def _safe_send(subject, message, email):
    try:
        send_mail(
            subject,
            message,
            settings.DEFAULT_FROM_EMAIL,
            [email],
            fail_silently=False,
        )
        return True
    except Exception as exc:
        logger.warning('Не удалось отправить письмо на %s: %s', email, exc)
        return False


def send_verification_email(user):
    code = generate_code()
    EmailVerification.objects.create(user=user, code=code)
    send_verification_code(user.email, user.first_name, code)
    return code


def send_verification_code(email, first_name, code):
    """Отправка кода подтверждения без обращения к БД (для pending-регистрации в сессии)."""
    message = (
        f'Здравствуйте, {first_name}!\n\n'
        f'Ваш код подтверждения: {code}\n\n'
        f'Код действителен {CODE_TTL_MINUTES} минут.\n\n'
        'Команда бара «Прибой»'
    )
    return _safe_send('Подтверждение регистрации — Бар «Прибой»', message, email)


def send_password_reset_email(user):
    code = generate_code()
    PasswordReset.objects.create(user=user, code=code)
    message = (
        f'Здравствуйте, {user.first_name}!\n\n'
        f'Код для восстановления пароля: {code}\n\n'
        f'Код действителен {CODE_TTL_MINUTES} минут.\n\n'
        'Если вы не запрашивали восстановление — проигнорируйте это письмо.\n\n'
        'Команда бара «Прибой»'
    )
    _safe_send('Восстановление пароля — Бар «Прибой»', message, user.email)
    return code


def _verify(model, user, code):
    threshold = timezone.now() - timedelta(minutes=CODE_TTL_MINUTES)
    record = model.objects.filter(
        user=user,
        code=code,
        is_used=False,
        created_at__gte=threshold,
    ).first()
    if record:
        record.is_used = True
        record.save(update_fields=['is_used'])
        return True
    return False


def verify_code(user, code):
    return _verify(EmailVerification, user, code)


def verify_password_reset_code(user, code):
    return _verify(PasswordReset, user, code)
