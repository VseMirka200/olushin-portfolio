from django import forms

from bookings.models import Review


class ReviewForm(forms.ModelForm):
    class Meta:
        model = Review
        fields = ['rating', 'text']
        widgets = {
            'text': forms.Textarea(attrs={
                'class': 'textarea',
                'rows': 3,
                'maxlength': 1000,
                'placeholder': 'Поделитесь впечатлением о позиции...',
            }),
        }

    def clean_rating(self):
        rating = self.cleaned_data.get('rating')
        if not rating or not (1 <= int(rating) <= 5):
            raise forms.ValidationError('Поставьте оценку от 1 до 5')
        return rating

    def clean_text(self):
        text = (self.cleaned_data.get('text') or '').strip()
        if len(text) < 3:
            raise forms.ValidationError('Отзыв слишком короткий')
        return text
