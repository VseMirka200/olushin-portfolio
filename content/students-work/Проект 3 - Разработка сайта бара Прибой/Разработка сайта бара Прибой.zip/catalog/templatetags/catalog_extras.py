from django import template
from django.conf import settings

register = template.Library()

DEFAULT_BAR = settings.MEDIA_URL + 'images/коктейль.jpg'
DEFAULT_KITCHEN = settings.MEDIA_URL + 'images/bar.jpg'
DEFAULT_HOOKAH = settings.MEDIA_URL + 'images/кальян.jpg'
DEFAULT_TABLE = settings.MEDIA_URL + 'images/стол.jpg'


@register.simple_tag
def service_image(service):
    first = service.images.first()
    if first and first.image:
        return first.image.url
    slug = (service.category.slug or '').lower()
    if 'kitchen' in slug or 'кух' in slug:
        return DEFAULT_KITCHEN
    if 'hookah' in slug or 'кальян' in slug:
        return DEFAULT_HOOKAH
    return DEFAULT_BAR


@register.simple_tag
def hookah_image(hookah):
    if hookah.image:
        return hookah.image.url
    return DEFAULT_HOOKAH


@register.simple_tag
def table_image(table):
    first = table.images.first()
    if first and first.image:
        return first.image.url
    return DEFAULT_TABLE


@register.simple_tag
def promotion_image(promotion):
    if promotion.image:
        return promotion.image.url
    return DEFAULT_BAR
