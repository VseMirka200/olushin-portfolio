import json

from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.template.loader import render_to_string
from django.views.decorators.http import require_GET, require_POST

from .forms import ReviewForm
from .models import Category, Service, Table


def _service_haystack(service):
    parts = [service.name or '', service.description or '']
    if service.category_id:
        parts.append(service.category.name or '')
    parts.extend(t.name for t in service.tags.all())
    return ' '.join(parts).lower()


def _services_search(query):
    """Поиск по услугам с учётом регистра и кириллицы.

    SQLite не умеет LOWER() для кириллицы, поэтому фильтрация в Python.
    Каталог небольшой — накладные расходы незаметны.
    """
    qs = Service.objects.select_related('category').prefetch_related('images', 'tags').filter(
        is_available=True,
    )
    query = (query or '').strip().lower()
    if not query:
        return list(qs)
    return [s for s in qs if query in _service_haystack(s)]


def index(request):
    return render(request, 'catalog/index.html', {
        'categories': Category.objects.all(),
        'services': _services_search(''),
    })


@require_GET
def catalog_search(request):
    if not getattr(request, 'htmx', None):
        return redirect('catalog:index')
    services = _services_search(request.GET.get('q', ''))
    return render(request, 'catalog/_catalog_cards.html', {'services': services})


def _service_reviews(service, user):
    qs = service.reviews.select_related('user').order_by('-created_at')
    if user.is_authenticated:
        return qs.filter(Q(is_approved=True) | Q(user=user))
    return qs.filter(is_approved=True)


def service_detail(request, slug):
    service = get_object_or_404(
        Service.objects.select_related('category').prefetch_related('images', 'tags'),
        slug=slug,
        is_available=True,
    )
    return render(request, 'catalog/service_detail.html', {
        'service': service,
        'reviews': _service_reviews(service, request.user),
        'review_form': ReviewForm(),
    })


@login_required
@require_POST
def add_review(request, slug):
    service = get_object_or_404(Service, slug=slug, is_available=True)
    form = ReviewForm(request.POST)

    if form.is_valid():
        review = form.save(commit=False)
        review.user = request.user
        review.service = service
        review.is_approved = False
        review.is_moderated = False
        review.save()
        form = ReviewForm()
        triggered = True
    else:
        triggered = False

    html = render_to_string('catalog/_reviews.html', {
        'service': service,
        'reviews': _service_reviews(service, request.user),
        'review_form': form,
    }, request=request)
    response = HttpResponse(html)
    if triggered:
        response['HX-Trigger'] = json.dumps({
            'priboi:toast': {
                'message': 'Отзыв отправлен и появится после проверки',
                'kind': 'success',
            }
        })
    return response


def table_detail(request, number):
    table = get_object_or_404(
        Table.objects.prefetch_related('images'),
        number=number,
        is_active=True,
    )
    return render(request, 'catalog/table_detail.html', {'table': table})
