from django.contrib import admin
from .models import Category, Tag, Service, Image, Table, TableImage, Hookah, Promotion


class ImageInline(admin.TabularInline):
    model = Image
    extra = 1
    fields = ['image', 'alt_text', 'is_primary', 'order']


class TableImageInline(admin.TabularInline):
    model = TableImage
    extra = 1
    fields = ['image', 'alt_text', 'is_primary', 'order']


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'slug', 'order']
    list_editable = ['order']
    search_fields = ['name']
    prepopulated_fields = {'slug': ('name',)}


@admin.register(Tag)
class TagAdmin(admin.ModelAdmin):
    list_display = ['name', 'slug']
    search_fields = ['name']
    prepopulated_fields = {'slug': ('name',)}


@admin.register(Service)
class ServiceAdmin(admin.ModelAdmin):
    list_display = ['name', 'category', 'price', 'is_available', 'created_at']
    list_filter = ['category', 'is_available', 'created_at']
    search_fields = ['name', 'description']
    prepopulated_fields = {'slug': ('name',)}
    filter_horizontal = ['tags']
    inlines = [ImageInline]
    date_hierarchy = 'created_at'


@admin.register(Table)
class TableAdmin(admin.ModelAdmin):
    list_display = ['number', 'capacity', 'status', 'occupied_until', 'is_active']
    list_filter = ['status', 'is_active']
    search_fields = ['number']
    inlines = [TableImageInline]
    list_editable = ['status', 'occupied_until']


@admin.register(Hookah)
class HookahAdmin(admin.ModelAdmin):
    list_display = ['name', 'price', 'is_available']
    list_filter = ['is_available']
    search_fields = ['name', 'description']
    list_editable = ['is_available']


@admin.register(Promotion)
class PromotionAdmin(admin.ModelAdmin):
    list_display = ['title', 'discount_percent', 'start_date', 'end_date', 'is_active']
    list_filter = ['is_active', 'start_date', 'end_date']
    search_fields = ['title', 'description']
    date_hierarchy = 'start_date'

