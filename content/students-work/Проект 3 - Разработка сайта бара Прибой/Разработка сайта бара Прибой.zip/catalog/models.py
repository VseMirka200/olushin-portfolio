from django.db import models
from django.utils.text import slugify
from django.core.validators import MinValueValidator


class Category(models.Model):
    """Категории услуг"""

    name = models.CharField('Название', max_length=100)
    slug = models.SlugField('Slug', unique=True)
    description = models.TextField('Описание', blank=True)
    icon = models.CharField('Иконка', max_length=50, blank=True, help_text='CSS класс иконки')
    order = models.PositiveIntegerField('Порядок', default=0)

    class Meta:
        verbose_name = 'Категория'
        verbose_name_plural = 'Категории'
        ordering = ['order', 'name']

    def __str__(self):
        return self.name


class Tag(models.Model):
    """Теги для поиска и фильтрации"""

    name = models.CharField('Название', max_length=50, unique=True)
    slug = models.SlugField('Slug', unique=True)

    class Meta:
        verbose_name = 'Тег'
        verbose_name_plural = 'Теги'
        ordering = ['name']

    def __str__(self):
        return self.name


class Service(models.Model):
    """Услуга/позиция меню"""

    name = models.CharField('Название', max_length=200)
    slug = models.SlugField('Slug', unique=True)
    description = models.TextField('Описание')
    price = models.DecimalField('Цена', max_digits=10, decimal_places=2, validators=[MinValueValidator(0)])
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='services', verbose_name='Категория')
    tags = models.ManyToManyField(Tag, related_name='services', verbose_name='Теги', blank=True)
    is_available = models.BooleanField('Доступно', default=True)
    created_at = models.DateTimeField('Создано', auto_now_add=True)
    updated_at = models.DateTimeField('Обновлено', auto_now=True)

    class Meta:
        verbose_name = 'Услуга'
        verbose_name_plural = 'Услуги'
        ordering = ['-created_at']

    def __str__(self):
        return self.name


class Image(models.Model):
    """Изображения услуг"""

    service = models.ForeignKey(Service, on_delete=models.CASCADE, related_name='images', verbose_name='Услуга')
    image = models.ImageField('Изображение', upload_to='services/')
    alt_text = models.CharField('Альтернативный текст', max_length=200, blank=True)
    is_primary = models.BooleanField('Основное', default=False)
    order = models.PositiveIntegerField('Порядок', default=0)

    class Meta:
        verbose_name = 'Изображение'
        verbose_name_plural = 'Изображения'
        ordering = ['order']

    def __str__(self):
        return f"Изображение для {self.service.name}"


class Table(models.Model):
    """Столы в баре"""

    STATUS_CHOICES = [
        ('free', 'Свободен'),
        ('occupied', 'Занят'),
        ('reserved', 'Забронирован'),
    ]

    number = models.CharField('Номер стола', max_length=10, unique=True)
    capacity = models.PositiveIntegerField('Вместимость', validators=[MinValueValidator(1)])
    description = models.TextField('Описание', blank=True)
    status = models.CharField('Статус', max_length=20, choices=STATUS_CHOICES, default='free')
    occupied_until = models.DateTimeField('Занят до', null=True, blank=True)
    is_active = models.BooleanField('Активен', default=True)

    class Meta:
        verbose_name = 'Стол'
        verbose_name_plural = 'Столы'
        ordering = ['number']

    def __str__(self):
        return f"Стол {self.number} (на {self.capacity} чел.)"


class TableImage(models.Model):
    """Изображения столов"""

    table = models.ForeignKey(Table, on_delete=models.CASCADE, related_name='images', verbose_name='Стол')
    image = models.ImageField('Изображение', upload_to='tables/')
    alt_text = models.CharField('Альтернативный текст', max_length=200, blank=True)
    is_primary = models.BooleanField('Основное', default=False)
    order = models.PositiveIntegerField('Порядок', default=0)

    class Meta:
        verbose_name = 'Изображение стола'
        verbose_name_plural = 'Изображения столов'
        ordering = ['order']

    def __str__(self):
        return f"Изображение для {self.table.number}"


class Hookah(models.Model):
    """Кальяны"""

    name = models.CharField('Название/Вкус', max_length=200)
    description = models.TextField('Описание')
    price = models.DecimalField('Цена', max_digits=10, decimal_places=2, validators=[MinValueValidator(0)])
    is_available = models.BooleanField('Доступно', default=True)
    image = models.ImageField('Изображение', upload_to='hookahs/', blank=True, null=True)

    class Meta:
        verbose_name = 'Кальян'
        verbose_name_plural = 'Кальяны'
        ordering = ['name']

    def __str__(self):
        return self.name


class Promotion(models.Model):
    """Акции и специальные предложения"""

    title = models.CharField('Заголовок', max_length=200)
    description = models.TextField('Описание')
    image = models.ImageField('Изображение', upload_to='promotions/', blank=True, null=True)
    discount_percent = models.PositiveIntegerField('Скидка %', null=True, blank=True, validators=[MinValueValidator(0)])
    start_date = models.DateTimeField('Начало')
    end_date = models.DateTimeField('Окончание')
    is_active = models.BooleanField('Активна', default=True)

    class Meta:
        verbose_name = 'Акция'
        verbose_name_plural = 'Акции'
        ordering = ['-start_date']

    def __str__(self):
        return self.title

