from django.urls import path
from . import views

app_name = 'catalog'

urlpatterns = [
    path('', views.index, name='index'),
    path('search/', views.catalog_search, name='search'),
    path('service/<slug:slug>/', views.service_detail, name='service_detail'),
    path('service/<slug:slug>/review/', views.add_review, name='add_review'),
    path('table/<str:number>/', views.table_detail, name='table_detail'),
]

