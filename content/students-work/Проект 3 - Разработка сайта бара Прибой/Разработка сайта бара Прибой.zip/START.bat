@echo off
title Bar Priboi - launch
cd /d "%~dp0"

echo.
echo ============================================================
echo   Bar "Priboi" - launching web application
echo ============================================================
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python is not installed.
    echo.
    echo Install Python 3.11 or higher from:
    echo   https://www.python.org/downloads/
    echo.
    echo During installation, check "Add Python to PATH".
    echo After installation, run this file again.
    pause
    exit /b 1
)

where node >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Node.js is not installed.
    echo.
    echo Install Node.js LTS from:
    echo   https://nodejs.org/
    echo.
    echo After installation, run this file again.
    pause
    exit /b 1
)

if not exist "venv\Scripts\python.exe" (
    echo [1/6] Creating Python virtual environment...
    python -m venv venv
    if errorlevel 1 (
        echo [ERROR] Failed to create venv.
        pause
        exit /b 1
    )
) else (
    echo [1/6] Virtual environment already exists.
)

echo [2/6] Installing Python dependencies...
call venv\Scripts\python.exe -m pip install --upgrade pip --quiet
call venv\Scripts\pip.exe install -r requirements.txt --quiet
if errorlevel 1 (
    echo [ERROR] Failed to install Python dependencies.
    pause
    exit /b 1
)

if not exist "node_modules" (
    echo [3/6] Installing npm packages...
    call npm install --silent
    if errorlevel 1 (
        echo [ERROR] Failed to install npm packages.
        pause
        exit /b 1
    )
) else (
    echo [3/6] npm packages already installed.
)

echo [4/6] Building Tailwind CSS...
call npm run build:css >nul 2>&1

echo [5/6] Applying database migrations...
call venv\Scripts\python.exe manage.py migrate --noinput

if not exist "db.sqlite3" (
    echo Loading test data...
    call venv\Scripts\python.exe manage.py create_test_data
)

echo [6/6] Opening browser...
start "" /B cmd /c "timeout /t 3 /nobreak >nul && start http://127.0.0.1:8000/"

echo.
echo ============================================================
echo   Site:  http://127.0.0.1:8000/
echo   Admin: http://127.0.0.1:8000/admin/
echo.
echo   Press Ctrl+C in this window to stop the server.
echo ============================================================
echo.

call venv\Scripts\python.exe manage.py runserver

pause
