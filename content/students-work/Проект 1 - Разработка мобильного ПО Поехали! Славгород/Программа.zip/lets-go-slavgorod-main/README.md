# Поехали! Славгород

![Баннер проекта](docs/assets/images/banner_1.png)

## О проекте

> [!IMPORTANT]
> Приложение «Поехали! Славгород» является неофициальным справочным приложением, не связано с администрацией, государственными учреждениями, такими перевозчиками, как ООО «Славгородское АТП», МУП «Торговый ряд г. Славгород», или иными муниципальными организациями, и не является их официальным приложением.

## Возможности

- список городских и пригородных маршрутов;
- поиск по номеру, названию, описанию, остановкам и времени отправления;
- отдельный экран расписания с фильтрами и ближайшими рейсами;
- закрепление избранных маршрутов;
- настройка источника данных расписания;
- системные уведомления об изменениях расписания;
- настройки темы, отображения и поведения интерфейса;

## Документация и сайт

- [Публичная страница проекта](https://vsemirka200.github.io/lets-go-slavgorod/)
- [Страница расписания](https://vsemirka200.github.io/lets-go-slavgorod/schedule.html)
- [Политика безопасности](https://drive.google.com/file/d/1DsT6W4P2a21jH7KYwEBNUdwZCR4_hRtE/view?usp=sharing)
- [Политика конфиденциальности](https://drive.google.com/file/d/1bru5Lo_PxcHaKhbvd50HXfUSo313j4Wp/view?usp=sharing)
- [Используемые библиотеки](https://drive.google.com/file/d/1ie1B3zC8lElfXiPFyVj58C669fvtAVVd/view?usp=sharing)

## Скриншоты

<img width="200" src="docs/assets/screenshots/screenshot_1.png" alt="Главный экран приложения"> <img width="200" src="docs/assets/screenshots/screenshot_2.png" alt="Список маршрутов"> <img width="200" src="docs/assets/screenshots/screenshot_3.png" alt="Экран расписания"> <img width="200" src="docs/assets/screenshots/screenshot_4.png" alt="Настройки">

## Обратная связь

Сообщить об ошибке, предложить улучшение или задать вопрос можно через [контакты](https://vsemirka200.github.io/lets-go-slavgorod/index.html#feedback).
